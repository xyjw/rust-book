use std::thread::sleep;
use std::time::Duration;
//  定义交通信号灯
enum TrafficLightColor {
	Color(String)
}
fn main() {
    // 变量index控制交通信号灯切换
    let mut index = 1;
    // 变量r2g控制红绿灯等待时间
    let r2g = 30;
    // 变量r2y控制红黄灯等待时间
    let r2y = 5;
    loop {
        // 红绿灯等待时间
        for i in 0..r2g {
            let mut t1 = TrafficLightColor::Color("红灯".to_string());
            let mut t2 = TrafficLightColor::Color("绿灯".to_string());
            if index % 2 == 1 {
                t1 = TrafficLightColor::Color("绿灯".to_string());
                t2 = TrafficLightColor::Color("红灯".to_string());
            }
            sleep(Duration::from_secs(1));
            // 输出等待时间
            if let TrafficLightColor::Color(v) = t1 {
                // 红灯时需要加上5秒，用于衔接下一个循环
                if v == "红灯".to_string() {
                    println!("t1的{:?}时间剩余{}秒", v, r2g-i+5);
                } else {
                    println!("t1的{:?}时间剩余{}秒", v, r2g-i);
                }
            };
            if let TrafficLightColor::Color(v) = t2 {
                // 红灯时需要加上5秒，用于衔接下一个循环
                if v == "红灯".to_string() {
                    println!("t2的{:?}时间剩余{}秒", v, r2g-i+5);
                } else {
                    println!("t2的{:?}时间剩余{}秒", v, r2g-i);
                }
            };
        }
        // 红黄灯等待时间
        for i in 0..r2y {
            let mut t1 = TrafficLightColor::Color("红灯".to_string());
            let mut t2 = TrafficLightColor::Color("黄灯".to_string());
            if index % 2 == 1 {
                t1 = TrafficLightColor::Color("黄灯".to_string());
                t2 = TrafficLightColor::Color("红灯".to_string());
            }
            // 延时1秒等待
            sleep(Duration::from_secs(1));
            // 输出等待时间
            if let TrafficLightColor::Color(v) = t1 {
                println!("t1的{:?}时间剩余{}秒", v, r2y-i);
            };
            if let TrafficLightColor::Color(v) = t2 {
                println!("t2的{:?}时间剩余{}秒", v, r2y-i);
            };
        }
        // 变量index自增加1，t1和t2切换红绿灯
        index += 1;
    }
}