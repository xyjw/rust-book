fn divide(numerator: f64, denominator: f64) -> Result<f64, String> {
    if denominator == 0.0 {
        Err("除数为0".to_string())
    } else {
        Ok(numerator / denominator)
    }
}

fn fn1() {
    let result = divide(4.0, 2.0);
    println!("使用unwrap：{}", result.unwrap());
}

fn fn2() {
    let result = divide(4.0, 2.0);
    match result {
        Ok(value) => println!("使用match：{}", value),
        Err(e) => println!("使用match：{}", e),
    }
}

fn fn3() {
    let result = divide(4.0, 2.0);
    if let Ok(value) = result {
        println!("使用if let：{}", value);
    }
}

fn fn4() -> Result<(), String>{
    let result = divide(4.0, 2.0);
    println!("“?”操作符：{}", result?);
    Ok(())
}

fn main() {
    fn1();
    fn2();
    fn3();
    fn4();
}