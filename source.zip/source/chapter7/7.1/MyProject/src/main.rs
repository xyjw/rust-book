enum Weekday {
   Monday,
   Tuesday,
   Wednesday,
   Thursday,
   Friday,
   Saturday,
   Sunday,
}

fn main() {
   let day: Weekday = Weekday::Friday;
   match day {
       Weekday::Monday => println!("万恶的周一！"),
       Weekday::Friday => println!("摆烂的周五！"),
       Weekday::Saturday | Weekday::Sunday => {
           println!("小周末愉快！");
       }
       _ => println!("工作天好难熬！"),
   }
}