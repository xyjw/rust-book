// 定义枚举
enum Info<T> {
   Data(T),
}

// 定义枚举的类型实现
impl<T> Info<T>{
   fn base(self) -> T {
       match self {
         Info::Data(a) => a,
       }
   }
}

impl<T, U> Info<(T,U)>{
   fn score(self) -> (T, U) {
       match self {
         Info::Data((a,b)) => (a, b),
       }
   }
}

fn main() {
   // 实例化Info
   let name = Info::Data("Tom");
   let age = Info::Data(20);
   let maths = Info::Data(("数学", 66));
   // 由枚举变量调用自定义方法
   println!("我的名字叫：{}", name.base());
   println!("我的年龄是：{}", age.base());
   let (a, b) = maths.score();
   println!("{}考试分数为：{}", a,b);
}