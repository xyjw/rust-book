enum Person {
   Name(String),
   Age(i32),
   Addr(String),
}

fn main() {
   // 实例化Person
   // 为每个变体设置相应变量和数值
   let name: Person = Person::Name(String::from("Tom"));
   let age: Person = Person::Age(18);
   let addr: Person = Person::Addr(String::from("China"));
   // 使用if let语法获取数据
   if let Person::Name(v) = name{
      println!("我的名字为：{}！", v);
   };
   // 使用关键字match获取数据
   match age {
      Person::Age(x) => println!("我的年龄为：{}！", x),
      _ => println!("我的年龄不告诉你！"),
   };
   // 使用if let语法获取数据
   if let Person::Addr(v) = addr{
      println!("我的住址在：{}！", v);
   };
}