// 定义枚举
enum Geometry {
   Area(i32),
   Perimeter((i32, i32)),
}

// 定义枚举的函数方法
impl Geometry {
   fn calculate(&self) -> i32 {
       match self {
         Geometry::Area(d) => d * d,
         Geometry::Perimeter(d) => (d.0 + d.1) * 2,
       }
   }
}

fn main() {
   // 实例化Geometry
   let area: Geometry = Geometry::Area(10);
   let perimeter: Geometry = Geometry::Perimeter((10, 20));
   // 由枚举对象调用自定义方法calculate()
   println!("矩形面积为：{}", area.calculate());
   println!("矩形周长为：{}", perimeter.calculate());
}