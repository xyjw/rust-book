// 定义模块
pub mod hello {
    pub fn world() {
        println!("hello world!")
    }
}