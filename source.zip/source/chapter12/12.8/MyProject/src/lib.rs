pub mod my_enum {
    pub enum Geometry {
        Area(i32),
        Perimeter((i32, i32)),
    }
    impl Geometry {
        pub fn calculate(&self) -> i32 {
            match self {
			Geometry::Area(d) => d * d,
			Geometry::Perimeter(d) => (d.0+d.1)*2,
        }
    }
    }
}
pub mod my_struct {
    pub struct Rectangle{
        pub length: f64,
        pub width: f64
     }
     // 定义结构体方法
     impl Rectangle{
        pub fn area(&self){
           let res = self.length * self.width;
           println!("长:{},宽:{},面积:{}",self.length,self.width,res)
        }
        pub fn perimeter(&self){
           let res = (self.length + self.width) * 2.0;
           println!("长:{},宽:{},周长:{}",self.length,self.width,res)
        }
     }
}