// 导入模块和函数所在文件
mod lib;
// 相对路径引用
use lib::*;
fn main() {
    // 调用模块的枚举对象
    let area = lib::my_enum::Geometry::Area(10);
    let perimeter = lib::my_enum::Geometry::Perimeter((10, 20));
   // 由枚举对象调用类型实现
   println!("矩形面积为：{}", area.calculate());
   println!("矩形周长为：{}", perimeter.calculate());
   // 调用模块的结构体
   let r = lib::my_struct::Rectangle{length: 6.0, width: 2.5};
   // 调用结构体方法计算面积
   r.area();
   // 调用结构体方法计算周长
   r.perimeter();
}