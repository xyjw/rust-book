// 导入模块所在文件
mod lib;
// 引用模块math
use lib::math;

fn main() {
	// 调用模块的函数
    println!("2 + 3 = {}", lib::math::add(2, 3));
    println!("5 - 2 = {}", lib::math::subtract(5, 2));
    // 调用模块的函数
    println!("2 + 3 = {}", math::add(2, 3));
    println!("5 - 2 = {}", math::subtract(5, 2));
}