// 定义模块名math
pub mod math {
    // 定义函数add
    pub fn add(x: i32, y: i32) -> i32 {
        x + y
    }
    // 定义函数subtract
    pub fn subtract(x: i32, y: i32) -> i32 {
        x - y
    }
}

