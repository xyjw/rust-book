// 导入模块和函数所在文件
mod lib;
// 相对路径引用
// 使用“{}”引入多个模块或函数
use lib::{go_school, school};
// 使用“*”引入所有模块或函数
use lib::*;
// 使用self和“{}”引入模块自身和模块函数
// 等价于use::lib::home和use::lib::home::eat
use lib::home::{self, eat};
fn main() {
    // 调用模块或函数
    go_school();
    go_home();
    go_mall();
}