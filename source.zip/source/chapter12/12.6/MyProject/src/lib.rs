// 定义模块
pub mod school {
    pub fn learn() {
        println!("好好学习，天天向上！")
    }
}

pub mod home {
    pub fn sleep() {
        println!("睡觉了，晚安！")
    }
    pub fn eat() {
        println!("吃饭长高高！")
    }
}

pub mod mall {
    pub fn shopping() {
        println!("购物最快乐！")
    }
    pub fn film() {
        println!("看电影！")
    }
}

// 定义函数
pub fn go_school() {
    println!("上学了！");
    school::learn();
}
pub fn go_home() {
    println!("回家了！");
    home::eat();
    home::sleep();
}
pub fn go_mall() {
    println!("逛商场了！");
    mall::film();
    mall::shopping();
}
