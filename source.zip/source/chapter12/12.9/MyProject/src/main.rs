// 从第三方包rand引入Rng trait
use rand::Rng;
fn main() {
    // 创建一个新的随机数生成器实例
    let mut rng = rand::thread_rng();
    // 生成一个0到99之间的随机整数
    let random_number = rng.gen_range(0..=99);
    println!("0到99之间的随机整数：{}", random_number);
    // 生成一个0.0到1.0之间的随机浮点数
    let random_float = rng.gen::<f64>();
    println!("0.0到1.0之间的随机浮点数：{}", random_float);
    // 生成一个随机布尔值
    let random_bool = rng.gen::<bool>();
    println!("随机布尔值：{}", random_bool);
}