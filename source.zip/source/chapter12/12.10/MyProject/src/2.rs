
#[derive(Debug)]
struct User {
    name: String,
    age: i32,
    height: i32,
}

fn main() {
    // 整型类型的数据排序
    let mut arr = vec![34, 15, 88, 2];
    // 使用sort排序
    arr.sort();
    println!("第一次排序结果：{:?}", arr);
    // 使用sort_unstable排序
    arr.sort_unstable();
    println!("第二次排序结果：{:?}", arr);
    // 字符串类型的数据排序
    // 按字符串长度排序
    let mut names = vec!["Bobb", "Alice", "Eve"];
    // 使用sort_by降序
    names.sort_by(|a, b| b.len().cmp(&a.len()));
    println!("第三次排序结果：{:?}", names);
    // 使用sort_by升序
    names.sort_by(|a, b| a.len().cmp(&b.len()));
    println!("第四次排序结果：{:?}", names);
    // 使用sort_by_key
    names.sort_by_key(|s| s.len());
    println!("第五次排序结果：{:?}", names);
    // 结构体多字段排序
    let mut u = vec![User{name: "Tim".to_string(), age: 18, height: 167},
                            User{name: "Tom".to_string(), age: 22, height: 178},];
    u.sort_by(|a, b| {
            b.name.cmp(&a.name)
            .then_with(|| b.age.cmp(&a.age))
            .then_with(|| a.height.cmp(&b.height))
    });
    println!("第六次排序结果：{:?}", u);
}