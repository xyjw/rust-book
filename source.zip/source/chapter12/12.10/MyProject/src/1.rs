fn bubble_sort(arr: &mut [i32]) {
    let n = arr.len();
    let mut swapped;
    for i in 0..n - 1 {
        swapped = false;
        for j in 0..n - i - 1 {
            if arr[j] > arr[j + 1] {
                arr.swap(j, j + 1);
                swapped = true;
            }
        }
        if !swapped {
            break;
        }
    }
}
fn main() {
    let mut arr = [5, 3, 8, 4, 2];
    bubble_sort(&mut arr);
    println!("排序后的结果：{:?}", arr);
}