// 导入模块或函数所在文件
mod lib;
// 绝对路径引用函数
use crate::lib::run;
// 相对路径引用函数
use lib::run;
fn main() {
    // 调用函数
    run();
}
