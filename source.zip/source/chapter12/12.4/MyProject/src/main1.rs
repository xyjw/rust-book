// 定义模块
mod hello {
    pub fn world() {
        println!("hello world!")
    }
}
// 绝对路径引用
use crate::hello::world;
// 相对路径引用
use hello::world;
fn main() {
    // 调用模块
    world();
}
