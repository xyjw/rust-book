// 定义模块
pub mod hello {
    pub fn world() {
        println!("hello world!")
    }
}
// 引用模块
// 在非crate根文件只能使用相对路径引用
// 相对路径
use hello::world;
// 定义函数
pub fn run() {
    world()
}
