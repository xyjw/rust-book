// 定义模块
pub mod person {
    // 在当前包可见
    pub(crate) fn get_name(name: &str) {
        println!("我的名字：{}！", name);
    }
    // 在当前模块中可见
    pub(self) fn get_age() {
        println!("我的年龄18岁！");
    }
    pub mod skill {
        // 嵌套模块skill为子模块
        // 父模块可见，即模块person
        pub(super) fn rap() {
            println!("我会唱跳rap！");
        }
        // 父模块可见，即模块person
        pub(in super) fn get_skill() {
            rap();
        }
    }
    // 无任何限制可见
    pub fn get_info(name: &str) {
        // 调用函数get_name
        get_name(name);
        // 调用函数get_age
        get_age();
        // 调用模块skill的get_skill
        skill::get_skill();
    }
}