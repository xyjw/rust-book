// 导入模块和函数所在文件
mod lib;
// 相对路径引用
use lib::person::get_info;
fn main() {
    // 调用模块或函数
    get_info("小明");
}