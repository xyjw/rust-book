pub mod restaurant {
    pub mod canteen {
        pub fn table() {
            println!("客人已坐下！")
        }
        pub fn order() {
            println!("客人扫码点餐了！")
        }
        pub fn eat() {
            println!("客人正在就餐！")
        }
        pub fn pay() {
            println!("客人结账！")
        }
    }
    pub mod kitchen {
        
        pub fn order() {
            println!("厨房收到客人点餐订单！")
        }
        pub fn cook() {
            println!("正在烹饪！")
        }
        pub fn serve() {
            println!("烹饪完成，请上菜！")
        }
    }
    pub mod reception {
        pub fn pay() {
            println!("服务台已收到账款！")
        }
    }
}