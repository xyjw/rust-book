// 导入模块所在文件
mod lib;
// 引用模块restaurant
use lib::restaurant;

fn main() {
    // 调用模块
	restaurant::canteen::table();
    restaurant::canteen::order();
    restaurant::kitchen::order();
    restaurant::kitchen::cook();
    restaurant::kitchen::serve();
    restaurant::canteen::eat();
    restaurant::canteen::pay();
    restaurant::reception::pay();
}