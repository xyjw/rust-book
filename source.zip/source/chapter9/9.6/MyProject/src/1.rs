fn main() {
   // 定义变量name
   let name = "Hello, Rust!";
   // 定义一个闭包，它捕获变量name
   let myfn = |param: &str| {
      println!("捕获变量name：{}", name);
      println!("函数参数param：{}", param);
   };
   // 调用闭包
   myfn("Hi Rust!");
   println!("输出变量name：{}", name);
}