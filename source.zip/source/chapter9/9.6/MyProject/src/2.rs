// 定义函数，其中参数f为闭包（即匿名函数）
// 参数f的数据类型为泛型F
// 泛型使用关键字where指定F的数据类型
fn myfn<F>(x: i32, f: F) -> i32 where F: Fn(i32) -> i32,
{
   // 调用函数
   return f(x)
}

fn main() {
   let x = 66;
   // 使用闭包作为函数参数
   let result = myfn(x, |x| x * 2);
   // 输出函数返回值
   println!("输出函数返回值：{}", result);
   println!("输出变量x：{}", x);
}