fn myfn<F>(mut x: i32, mut f: F) -> i32 where F: FnMut(i32) -> i32,
{
   // 修改参数x
   // 参数x在匿名函数里被使用，对匿名函数的数值有影响作用
   x = x + 1;
   // 调用函数
   return f(x)
}

fn main() {
   let x = 66;
   // 使用闭包作为函数参数
   let result = myfn(x, |x| x * 2);
   // 输出函数返回值
   println!("输出函数返回值：{}", result);
   println!("输出变量x：{}", x);
}