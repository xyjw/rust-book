// 定义结构体
// 设置匿名标签'a, 'b
// 在字段数据类型前面添加&'a或&'b
struct Person<'a, 'b> {
   name: &'a String,
   age: &'b i32
}

fn main() {
   // 定义变量name和age
   let name = String::from("Rust");
   let age = 18;
   // 将变量name和age作为不可变引用传入结构体
   let p = Person{name: &name, age: &age};
   // 访问结构体字段
   println!("结构体字段name：{}", p.name);
   println!("结构体字段age：{}", p.age);
   println!("变量name：{}", name);
   println!("变量：{}", p.age);
}