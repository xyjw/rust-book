fn main() {
   let x = 5;
   let y = x;
   println!("x = {x}, y = {y}"); // 输出：x = 5, y = 5
}
