fn print_str(str: String){
   println!("这是复合类型的字符串：{}", str)
}
fn print_int(int: i32){
   println!("这是基本数据类型的整型：{}", int)
}
fn main() {
   let i = 66;
   let s = String::from("Hello Rust");
   // 调用函数
   print_int(i);
   print_str(s);
   // 输出原有变量
   println!("i = {i}");
   // 变量s无法输出，提示异常borrow of moved value
   // println!("s = {s}");
}
