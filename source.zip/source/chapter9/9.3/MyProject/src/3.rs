fn main() {
   let s1 = String::from("Hello Rust");
   let s2 = s1;
   println!("s1 = {s1}, s2 = {s2}");
}
