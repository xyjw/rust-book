fn main() {
   let s1 = String::from("Hello Rust");
   let s2 = s1.clone();
   println!("s1 = {s1}, s2 = {s2}");
   // 输出：s1 = Hello Rust, s2 = Hello Rust
}
