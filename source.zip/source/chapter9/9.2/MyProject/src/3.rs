// 定义Trait
trait Container {
   // 设置类型别名
   type X;
   type Y;
   // 函数定义
   fn get_x(&self) -> &Self::X;
   fn get_y(&self) -> &Self::Y;
}
// 定义结构体
struct Point<T, U>{
   x: T,
   y: U,
}
// 将结构体与Trait绑定
impl<T, U> Container for Point<T, U> {
   // 将类型别名Item设为泛型
   type X = T;
   type Y = U;
   // 重新定义函数
   fn get_x(&self) -> &T {
      return &self.x
   }
   fn get_y(&self) -> &U {
      return &self.y
   }
}
fn main() {
   // 实例化结构体
   let p = Point{x:100, y: 200};
   // 调用函数并输出
   println!("结构体的字段x的值：{}", p.get_x());
   println!("结构体的字段y的值：{}", p.get_y());
}