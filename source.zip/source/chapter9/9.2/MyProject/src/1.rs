// 定义Trait
trait Printable {
   // 只定义函数
   fn print(&self);
   // 定义整个函数
   fn print_all(&self){
      println!("这是Trait定义整个函数！")
   }
}

// 实现结构体
struct Message {
   content: String,
}
// 将结构体与Trait绑定
impl Printable for Message {
   // 实现print函数的功能逻辑
   fn print(&self) {
      println!("这是实现Trait定义函数的功能逻辑！");
      println!("输出结构体的字段：{}", self.content);
   }
}

fn main() {
   // 实例化结构体
   let msg = Message{content: "Hello, Rust!".to_string()};
   // 调用Trait定义的函数
   msg.print();
   msg.print_all();
}