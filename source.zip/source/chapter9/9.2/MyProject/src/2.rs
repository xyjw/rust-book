// 定义Trait
trait Container {
   // 设置类型别名
   type Item;
   // 函数定义
   fn get(&self) -> &Self::Item;
}
// 定义结构体
struct Message<T>{
   content: T,
}
// 将结构体与Trait绑定
impl<T> Container for Message<T> {
   // 将类型别名Item设为泛型
   type Item = T;
   // 重新定义函数
   fn get(&self) -> &T {
      return &self.content
   }
}
fn main() {
   // 实例化结构体
   let msg = Message{content:100};
   // 调用函数并输出
   println!("结构体的字段值：{}", msg.get());
}