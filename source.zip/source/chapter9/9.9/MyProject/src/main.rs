// 引入标准库的alloc模块，它提供内存分配功能  
use std::alloc::{alloc, Layout};  

// 定义函数，分配一段内存并返回一个指向该内存的裸指针
// 这个函数是unsafe的，因为它直接操作了内存
unsafe fn allocate_memory(size: usize) -> *mut u8 {
   // 创建一个Layout对象，它描述了要分配的内存的布局
   let layout = Layout::from_size_align_unchecked(size, 1);
   // 使用alloc函数分配内存
   // alloc函数返回一个Option<*mut u8>
   let ptr = alloc(layout);
   // 如果分配成功，返回指向该内存的裸指针
   return ptr
}

// 定义函数，释放之前分配内存
// 这个函数也是unsafe的
unsafe fn free_memory(ptr: *mut u8, size: usize) {
   // 创建一个Layout对象，它描述了要释放的内存的布局
   let layout = Layout::from_size_align_unchecked(size, 1);
   // 使用dealloc函数释放内存
   // 注意：必须确保传递给dealloc的指针和大小与alloc创建的相同
   std::alloc::dealloc(ptr, layout);
}
  
fn main() {
   // 在unsafe块中调用allocate_memory和free_memory
   unsafe {
      // 分配一块大小为100字节的内存
      let ptr = allocate_memory(100);
      // 给指针指向内存赋值，数据类型为u8类型
      *ptr = 66;
      // 输出指针指向内存所保存的值
      println!("输出指针指向内存所保存的值：{}", *ptr);
      // 释放内存
      // 注意：释放内存，ptr变成悬挂指针（Dangling Pointer）
      // 它不再指向有效的内存区域，因此不能使用
      free_memory(ptr, 100);
   }  
   // unsafe代码块之外不可再访问ptr
}