fn main() {
   // 定义动态数组
   let v = vec![1, 2, 3, 4, 5];
   // 数组转换只读迭代器
   // 添加mut，调用next()和next_back()会改变迭代器元素
   let mut its = v.iter();
   // 调用next()获取迭代器数据
   let data = its.next().unwrap();
   // 输出数据
   println!("调用next()获取迭代器数据：{}", data);
   // 调用next_back()获取迭代器数据
   let data = its.next_back().unwrap();
   println!("调用next_back()获取迭代器数据：{}", data);
   // 使用fold()累加迭代器的元素
   // 调用了next()和next_back()，只能计算2+3+4的结果
   let result = its.fold(0, |acc, &x| acc + x);
   println!("使用fold()累加迭代器元素：{:?}",result);
   
   // 定义动态数组
   let mut v1 = vec![1, 2, 3, 4, 5];
   // 数组转换可写迭代器
   let its = v1.iter_mut();
   // 修改迭代器的数据
   for i in its {
      // 解引用并修改值
      *i += 1;
   }
   // 输出动态数组数据，查看数据是否修改
   println!("输出动态数组数据：{:?}", v1);
   
   // 定义动态数组
   let v2: Vec<i32> = vec![1, 2, 3, 4, 5];
   // 数组转换所有权转移迭代器
   let its = v2.into_iter();
   // 使用filter()过滤元素并创建新的迭代器
   // filter()使用匿名函数实现元素过滤
   let f = its.filter(|&x| x % 2 == 0);
   // 使用collect()将迭代器转换动态数组
   // 变量new1需要设置数据类型
   let new1: Vec<i32> = f.collect();
   println!("过滤元素并转换数组：{:?}", new1);
}