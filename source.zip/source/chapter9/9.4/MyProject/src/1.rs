fn print_str(str: &String){
   // 函数参数为不可变引用
   println!("这是函数里面的字符串：{}", *str)
}
fn main() {
   let s = String::from("Hello");
   // 调用函数
   // 设置不可变引用
   print_str(&s);
   println!("这是主函数的字符串：{}", s)
}