fn print_str(str: &mut String){
   // 函数参数为可变引用
   str.push_str(" Rust");
   println!("这是函数里面的字符串：{}", *str)
}
fn main() {
   let mut s = String::from("Hello");
   // 调用函数
   // 设置可变引用
   print_str(&mut s);
   println!("这是主函数的字符串：{}", s)
}