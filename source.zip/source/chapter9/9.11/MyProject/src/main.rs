use std::collections::HashMap;
use std::io;

// 定义初始化trait，返回Self类型
trait RoleInit {
    fn init() -> Self;
}
// 定义用户角色结构体Role
#[derive(Debug)]
struct Role {
    name: String,
    profession: String,
    attack: i32,
    skill: Vec<String>,
    money: i32,
    goods: Vec<HashMap<String, i32>>,
    wear: HashMap<String, String>,
}
// 将trait绑定到结构体Role
impl RoleInit for Role {
    // 重写RoleInit()
    fn init() -> Self {
        Role {
            name: String::new(),
            profession: String::new(),
            attack: 10,
            skill: vec!["普通攻击".to_string()],
            money: 0,
            goods: Vec::new(),
            wear: HashMap::new(),
        }
    }
}
fn main() {
    // 使用trait初始化角色
    let mut role = Role::init();
    // 获取用户输入
    println!("欢迎来到西西村！请输入并创建你的名字：");
    let mut name = String::new();
    io::stdin().read_line(&mut name).expect("读取输入失败");
    role.name = name.trim().to_string();
    // 职业选择逻辑
    loop {
        println!("请选择你的职业：1-剑士，2-法师，3-弓箭手：");
        let mut profession = String::new();
        io::stdin().read_line(&mut profession).expect("读取输入失败");
        match profession.trim() {
            "1" => {
                role.profession = "剑士".to_string();
                role.skill.push("基础剑术".to_string());
                break;
            }
            "2" => {
                role.profession = "法师".to_string();
                role.skill.push("基础法术".to_string());
                break;
            }
            "3" => {
                role.profession = "弓箭手".to_string();
                role.skill.push("基础箭法".to_string());
                break;
            }
            _ => {
                println!("输入有误，请重新选择：");
                continue;
            }
        }
    }
    // 输出角色信息
    println!("人物名称：{}", role.name);
    println!("人物职业：{}", role.profession);
    println!("人物技能：{:?}", role.skill);

    // 学习技能
    let skill = match role.profession.as_str() {
        "剑士" => "剑刃冲击",
        "法师" => "火球术",
        "弓箭手" => "心神凝聚",
        _ => "",
    };
    println!(
        "你好，{}，我是西西村村长，最近野兽森林里出现了山贼，\
        捉走了采药的村民。这里有一本{}，希望你能营救村民。",
        role.name, skill
    );
    println!("系统提示：习得{}", skill);
    role.skill.push(skill.to_string());

    // 获得物品
    println!(
        "你好，{}，我是药铺老板，我的员工在采药时被山贼捉去，\
        这里有10瓶金疮药和100两银子，希望你能解救我的员工。",
        role.name
    );
    let mut item = HashMap::new();
    item.insert("金疮药".to_string(), 10);
    role.goods.push(item);
    role.money += 100;
    println!("系统提示：获得10瓶金疮药和100两银子");

    // 选择路线
    loop {
        println!("选择你的路线：1-兵器铺，2-野兽森林，3-退出");
        let mut ways = String::new();
        io::stdin().read_line(&mut ways).expect("读取输入失败");
        
        match ways.trim() {
            "1" => {
                println!("本店出售兵器，总有一款适合你。");
                println!("木杖—60两 +18攻击：选择1");
                println!("木剑—60两 +18攻击：选择2");
                println!("木弓—60两 +18攻击：选择3");
                println!("布衣—30两 +10防御：选择4");
                
                let mut wear = String::new();
                io::stdin().read_line(&mut wear).expect("读取输入失败");
                
                match (wear.trim(), role.profession.as_str()) {
                    ("1", "法师") => {
                        role.attack += 18;
                        role.money -= 60;
                        role.wear.insert("arms".to_string(), "木杖".to_string());
                    }
                    ("2", "剑士") => {
                        role.attack += 18;
                        role.money -= 60;
                        role.wear.insert("arms".to_string(), "木剑".to_string());
                    }
                    ("3", "弓箭手") => {
                        role.attack += 18;
                        role.money -= 60;
                        role.wear.insert("arms".to_string(), "木弓".to_string());
                    }
                    ("4", _) => {
                        role.attack += (10.0 * 0.2) as i32;
                        role.money -= 30;
                        role.wear.insert("clothes".to_string(), "布衣".to_string());
                    }
                    _ => println!("选择的装备与你的职业不相符"),
                }
            }
            "2" => println!("野兽森林功能待完善"),
            "3" => break,
            _ => println!("无效选择"),
        }
    }

    // 最终角色信息
    println!("人物名称：{}", role.name);
    println!("人物职业：{}", role.profession);
    println!("人物技能：{:?}", role.skill);
    println!("人物攻击力：{}", role.attack);
    println!("人物金钱：{}", role.money);
    println!("人物装备：{:?}", role.wear);
    println!("人物物品：{:?}", role.goods);
}