// 定义声明式宏
macro_rules! print_args {
   // 如果没有参数
   () => {
      println!("Hello Rust!");
   };
   // 如果有一个或多个参数
   ($($x:expr),*) => {
      $(println!("{}", $x);)*
   };
}

fn main() {
   // 调用无参数的宏
   print_args!();
   // 调用带有多个参数的宏
   print_args!("Hi, Rust!", "This is Macro");
}