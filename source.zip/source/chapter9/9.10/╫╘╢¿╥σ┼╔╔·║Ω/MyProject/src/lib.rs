use proc_macro::TokenStream;
use quote::quote;
use syn::{parse, DeriveInput};

// 使用proc_macro_derive设为派生宏
#[proc_macro_derive(MyMacro)]
pub fn my_derive(input: TokenStream) -> TokenStream {
    // 解析 DeriveInput 结构体
    let ast: DeriveInput = parse(input).unwrap();
    // 为该类型实现一个函数
    // ast.ident是获取结构体名称
    let name = ast.ident;
    // 使用quote!生成新的Rust代码
    let gen = quote! {
        // 为结构体定义方法
        impl #name {
            fn macros() {
                println!("My name is {}", stringify!(#name));
            }
        }
    };
    gen.into()
}