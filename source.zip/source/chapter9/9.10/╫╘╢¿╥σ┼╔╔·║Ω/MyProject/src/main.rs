// 导入lib.rs自定义宏MyMacro
use MyProject::MyMacro;
// 将结构体Person添加派生宏
#[derive(MyMacro)]
struct Person;

fn main() {
   // 调用派生宏
   Person::macros();
}