use proc_macro::TokenStream;
use quote::quote;
use syn::{parse_macro_input, ItemFn};

#[proc_macro_attribute]
pub fn handles(_attr: TokenStream, item: TokenStream) -> TokenStream {
    // 使用parse_macro_input!将函数转换ItemFn类型
    let mut func = parse_macro_input!(item as ItemFn);
    // 获取函数名称
    let func_name = &func.sig.ident;
    // 获取函数的实现部分，即函数体
    let func_block = &func.block;
    // 修改函数体的代码块
    let output = quote! {
        {
            println!("开始调用：{}", stringify!(#func_name));
            // 函数体代码
            { #func_block };
            println!("结束调用：{}", stringify!(#func_name));
        }
    };
    // 将修改后的代码重新写入func.block
    func.block = syn::parse2(output).unwrap();
    // 将func作为返回值
    quote! { #func }.into()
}
