// 导入lib.rs的属性宏
use MyProject::handles;
// 为函数添加属性宏
#[handles]
fn index() {
    println!("Hello Rust!");
}
fn main() {
   // 调用函数
   index()
}