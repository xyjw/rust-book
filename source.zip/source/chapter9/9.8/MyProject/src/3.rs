// 为动态数组定义新名称NewVector
type NewVector<T> = Vec<T>;
fn main() {
   // 使用别名NewVector定义变量
   let vec: NewVector<f64> = vec![1.0, 2.0, 3.0];
   println!("动态数组：{:?}", vec);
}