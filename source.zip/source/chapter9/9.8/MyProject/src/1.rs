// 为f64类型定义了一个新的名称Newfloat
type Newfloat = f64;
fn main() {
   // 使用别名Newfloat定义变量
   let f: Newfloat = 100.66;
   println!("浮点数：{}", f);  
}