// 为(f64, f64)元组定义新名称Point
type Point = (f64, f64);
fn main() {  
   // 使用别名Point定义变量
   let p: Point = (6.6, 7.7);
   println!("元组：({}, {})", p.0, p.1);
}