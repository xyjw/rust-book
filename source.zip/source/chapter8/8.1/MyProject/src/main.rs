// 定义结构体
struct Point {
   x: i32,
   y: i32,
}

fn main() {
   // 实例化结构体
   let p = Point{x: 10, y:20};
   // 通过结构体实例对象访问字段x和y
   println!("结构体Point的坐标为：{}, {}", p.x, p.y); 
}