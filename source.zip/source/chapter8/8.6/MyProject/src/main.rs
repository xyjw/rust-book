// 使用内置派生trait
#[derive(Debug, Eq, PartialEq)]
struct Point {
    x: i32,
    y: i32,
}
fn main() {
   // 实例化结构体
   let point1 = Point { x: 0, y: 0 };
   let point2 = Point { x: 0, y: 0 };
   let point3 = Point { x: 1, y: 1 };
   // 使用派生trait-Debug打印调试信息
   println!("{:?}", point1);
   // 使用派生trait-Eq和PartialEq进行比较
   if point1 == point2 {  
      println!("point1和point2相等");
   } else {
      println!("point1和point2不相等");
   }
   if point1 == point3 {
      println!("point1和point3相等");
   } else {
      println!("point1和point3不相等");
   }
}