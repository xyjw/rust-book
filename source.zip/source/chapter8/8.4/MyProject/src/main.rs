// 定义元组结构体
struct Tuples(i32, f64);
// 定义单元结构体
struct Units;
// 结构体的函数方法
impl Units {
   fn get(&self) {
      println!("这是单元结构体UnitStruct");
   }
}
// 定义普通结构体
struct Normal{
   value: i32
}
// 定义普通结构体
// 字段嵌套普通结构体、元组结构体和单元结构体
struct MyStruct{
   normal: Normal,
   tuples: Tuples,
   units: Units
}

fn main() {
   // 实例化结构体
   let s = MyStruct{
      normal: Normal{value: 67},
      tuples: Tuples(66, 77.77),
      units: Units
   };
   println!("字段是普通结构体的字段：{}", s.normal.value);
   println!("字段是元组结构体的第一个字段：{}", s.tuples.0);
   println!("字段是元组结构体的第二个字段：{}", s.tuples.1);
   s.units.get()
}