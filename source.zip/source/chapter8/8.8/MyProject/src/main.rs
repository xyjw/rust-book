struct TaxiMeter {
    start_fare: f64,        // 起步价
    per_km: f64,            // 每公里费用
    per_minute: f64,        // 每分钟等待费
    night_surcharge: f64,   // 夜间服务附加费比例
}

impl TaxiMeter {
    // 计算总费用
    fn calculate_fare(&self, distance_km: f64, wait_time_min: f64, is_night: bool) -> f64 {
        // 计算基础费用
        let base_fare = self.start_fare 
            + (distance_km * self.per_km)
            + (wait_time_min * self.per_minute);

        // 计算夜间附加费
        if is_night {
            base_fare * (1.0 + self.night_surcharge)
        } else {
            base_fare
        }
    }

    // 创建一个新的计价器实例
    fn new(start_fare: f64, per_km: f64, per_minute: f64, night_surcharge: f64) -> Self {
        TaxiMeter {
            start_fare,
            per_km,
            per_minute,
            night_surcharge,
        }
    }
}

fn main() {
    // 初始化计价器参数（示例值）
    let meter = TaxiMeter::new(
        10.0,   // 起步价 10 元
        2.0,    // 每公里 2 元
        0.5,    // 每分钟等待费 0.5 元
        0.2     // 夜间附加费 20%
    );
    // 示例计算
    let daytime_fare = meter.calculate_fare(15.0, 8.0, false);
    let nighttime_fare = meter.calculate_fare(15.0, 8.0, true);
    // 格式化输出结果（保留两位小数）
    println!("白天费用：{:.2}元", daytime_fare);
    println!("夜间费用：{:.2}元", nighttime_fare);
}