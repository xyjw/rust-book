// 定义泛型结构体
struct Point<T, U> {
   x: T,
   y: U,
}
// 定义泛型结构体方法
impl<T, U> Point<T, U>{
   fn get_gx(&self) -> &T{
      return &self.x
   }
   fn get_gy(&self) -> &U{
      return &self.y
   }
}
// 定义结构体方法
impl Point<i32, f64> {
   fn get_x(&self) -> i32{
      return self.x - 1
   }
   fn get_y(&self) -> f64{
      return self.y - 1.0
   }
}

fn main(){
   // 实例化结构体
   let p = Point{x: 66, y: 77.77};
   // 调用泛型结构体方法
   println!("从泛型结构体方法获取x：{:?}", p.get_gx());
   println!("从泛型结构体方法获取y：{:?}", p.get_gy());
   // 调用结构体方法
   println!("从结构体方法获取x并减1：{:?}", p.get_x());
   println!("从结构体方法获取y并减1：{:?}", p.get_y());
}
