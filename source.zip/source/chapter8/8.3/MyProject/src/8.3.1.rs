// 定义单元结构体
struct UnitStruct;
// 结构体的函数方法
impl UnitStruct {
   fn get(&self) {
      println!("这是单元结构体UnitStruct");
   }
}

fn main() {
   // 实例化单元结构体
   let u = UnitStruct;
   // 调用结构体的函数方法
   u.get();
}