// 使用单元结构体作为标记类型
struct Ready;
struct Completed;

// 定义枚举，变体分别为结构体Ready和Completed
enum State {
    Ready(Ready),
    Completed(Completed),
}
// 自定义函数
fn task(state: State) {
   // 使用match匹配枚举对象的枚举值
   match state {
      State::Ready(_) => println!("预备备"),
      State::Completed(_) => println!("结束了"),
   }
}
fn main() {
   // 调用自定义函数，并将枚举实例化对象作为参数
   task(State::Ready(Ready)); 
   task(State::Completed(Completed)); 
}