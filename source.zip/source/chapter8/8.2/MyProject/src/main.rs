// 定义元组结构体
struct Point(i32, f64);

fn main() {
   // 实例化元组结构体
   let p = Point(66, 77.77);
   // 访问结构体第一个字段
   println!("结构体Point的第一个字段：{}", p.0); 
   // 访问结构体第二个字段
   println!("结构体Point的第二个字段：{}", p.1); 
}