// 定义结构体
struct Rectangle{
   length: f64,
   width: f64
}
// 定义结构体方法
impl Rectangle{
   fn area(&self){
      let res = self.length * self.width;
      println!("长:{}，宽：{}，面积:{}", self.length, self.width, res)
   }
   fn perimeter(&self){
      let res = (self.length + self.width) * 2.0;
      println!("长:{}，宽:{}，周长:{}", self.length, self.width, res)
   }
}

fn main() {
   // 实例化结构体
   let r = Rectangle{length: 6.0, width: 2.5};
   // 调用函数方法计算面积
   r.area();
   // 调用函数方法计算周长
   r.perimeter();
}