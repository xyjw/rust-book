// 定义递归函数
fn fibonacci(x:i32) ->i32 {
   if x < 2 {
      return x;
   }
   // 调用自身，传入不同参数值
   return fibonacci(x-2) + fibonacci(x-1);
}
fn main() {
   for i in 0..10{
      // 调用函数fibonacci()
      let a = fibonacci(i);
      print!("{} ", a)
   }
   println!()
}