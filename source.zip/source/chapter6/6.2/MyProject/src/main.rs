fn add(x: Option<i32>, y: Option<i32>){
   let x1 = x.unwrap_or(0);
   let y1 = y.unwrap_or(0);
   println!("x+y={}", x1+y1)
}

fn main() {
   add(Some(1), Some(2));
   add(Some(1), None)
}

// 使用关键字match获取数据
fn value_match(x: Option<i32>) {  
   match x {  
       Some(v) => println!("数据为：{}", v),  
       None => println!("这是None"),  
   }  
}
// 使用if let语法获取数据
fn value_if_let(x: Option<i32>) {  
   if let Some(v) = x {  
       println!("数据为：{}", v);  
   } else {  
       println!("这是None");  
   }  
}