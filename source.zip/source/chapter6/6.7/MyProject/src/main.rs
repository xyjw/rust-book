// 定义文件后缀名创建函数
// 函数返回值为函数类型
fn suffixc(suffix: &str) -> impl Fn(String) -> String + '_ {
    // 闭包捕获参数suffix
    |name: String| {
        // 假设文件名以'.'开头即视为已有后缀
        if let Some(_x) = name.rfind(".") {
            // 文件名已包含后缀
            format!("文件已有后缀名：{}", name)
        } else {
            // 文件名不包含后缀，添加新后缀
            name + suffix
        }
    }
}
fn main() {
    // 定义JPG和TXT的闭包  
    let jpg_func = suffixc(".jpg");
    let txt_func = suffixc(".txt");
    // 使用闭包
    println!("{}", jpg_func("test.png".to_string()));  
    println!("{}", txt_func("test".to_string()));  
}