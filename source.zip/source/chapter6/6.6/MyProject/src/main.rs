fn add<T: std::ops::Add<Output = T>>(x: T, y: T) -> T{
   return x + y;
}

fn main() {
   let r = add(1, 2);
   println!("整数相加的值为：{}", r);
   let r = add(1.1, 2.2);
   println!("浮点数相加的值为：{}", r);
}
