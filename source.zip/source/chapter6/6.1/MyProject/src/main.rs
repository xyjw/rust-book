// 无参数无返回值的函数
fn add() {
   let r = 1 + 1;
   println!("1+1={}", r)
}
 // 有参数无返回值的函数
 fn subtraction(a: i32, b: i32) {
   let c = a - b;
   println!("a-b={}", c)
 }
// 无参数有返回值的函数
fn multiplication() -> i32{
   return 6;
}
// 有参数有返回值的函数
fn division(a: i32, b: i32) -> i32 {
   if b == 0 {
      println!("除数不能为0");
      return 0;
   }else{
      return a/b;
   }
}

fn main() {
   add();
   subtraction(2, 1);
   let m = multiplication();
   println!("返回值为：{}", m);
   let d = division(4, 2);
   println!("商为：{}", d);
}