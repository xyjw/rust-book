// 定义函数
fn myfn(){
   println!("自定义函数")
}

fn main() {
   // 定义函数变量
   let m: fn();
   // 将函数作为变量m的值
   m = myfn;
   // 调用函数
   m();
}