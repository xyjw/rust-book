use time;
use time::macros::*;
fn main() {
    // 获取当前本地时间
    let t1 = time::OffsetDateTime::now_local().unwrap();
    println!("当前本地时间：{}", t1.to_string());
    // 当前时间的2小时后
    let res = t1.saturating_add(time::Duration::hours(2));
    println!("当前时间的2小时后：{}", res.to_string());
    // 当前时间的3小时前
    let res = t1.saturating_add(time::Duration::hours(-3));
    println!("当前时间的3小时前：{}", res.to_string());
    // 当前时间的2小时前
    let res = t1.saturating_sub(time::Duration::hours(2));
    println!("当前时间的2小时前：{}", res.to_string());
    // 当前时间的3小时后
    let res = t1.saturating_sub(time::Duration::hours(-3));
    println!("当前时间的3小时后：{}", res.to_string());
    // 当前时间的1天后
    let res = t1.checked_add(time::Duration::days(1)).unwrap();
    println!("当前时间的1天后：{}", res.to_string());
    // 当前时间的2天前
    let res = t1.checked_add(time::Duration::days(-2)).unwrap();
    println!("当前时间的2天前：{}", res.to_string());
    // 当前时间的1天前
    let res = t1.checked_sub(time::Duration::days(1)).unwrap();
    println!("当前时间的1天前：{}", res.to_string());
    // 当前时间的2天后
    let res = t1.checked_sub(time::Duration::days(-2)).unwrap();
    println!("当前时间的2天后：{}", res.to_string());
}