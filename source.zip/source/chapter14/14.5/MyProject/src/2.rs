use time;
use time::macros::*;
fn main() {
    // 使用宏语法生成日期
    let d1 = date!(2025-01-01);
    let d2 = date!(2025-01-03);
    // 计算两个日期之间相差天数
    let res = (d2 - d1).whole_days();
    println!("两个日期之间相差天数：{}", res);

    // 使用宏语法生成时间
    let t1 = time!(08:30:00);
    let t2 = time!(15:30:00);
    // 计算两个时间之间相差小时数
    let res = (t2 - t1).whole_hours();
    println!("两个时间之间相差小时数：{}", res);

    // 使用宏语法生成日期时间
    let dt1 = datetime!(2025-01-01 08:30:00);
    let dt2 = datetime!(2025-01-02 15:30:00);
    // 计算两个日期时间之间相差小时数
    let res = (dt2 - dt1).whole_hours();
    println!("两个日期时间之间相差小时数：{}", res);
}