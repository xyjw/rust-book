use std::thread::sleep;
use std::time::Duration;
use time;
fn main() {
    let st = time::OffsetDateTime::now_utc().time().to_string();
    println!("开始时间为：{}", st);
    let dur = Duration::from_secs(3);
    sleep(dur);
    let et = time::OffsetDateTime::now_utc().time().to_string();
    println!("结束时间为：{}", et);
}