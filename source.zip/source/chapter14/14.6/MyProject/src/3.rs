use time;
use std::thread::sleep;
use std::time::Duration;
// 定义定时任务
fn task() {
    println!("执行任务了！")
}
fn main() {
    // 标记状态，确保在定时范围内只执行一次任务
    let mut status = true;
    loop {
        // 获取当前时间
        let nt = time::OffsetDateTime::now_local().unwrap().hour();
        // 判断是否早上9点
        if nt == 9 && status == true {
            // 执行任务
            task();
            status = false;
        } else {
            // 延时5秒
            sleep(Duration::from_secs(5));
            println!("等待中......");
            // 如果不在定时范围内则改变status状态
            if nt != 9 && status == false {
                status = true;
            }
        }
    }
}
