use tokio::time::{timeout, Duration};

// 定义异步函数，模拟一个耗时的操作
async fn runing() {
    // 模拟10秒的操作
    tokio::time::sleep(Duration::from_secs(10)).await;
}
// 定义异步函数，执行函数runing并设置超时
#[tokio::main]
async fn begin() {
    // 使用 timeout函数为异步操作设置超时时间（例如5秒）
    let result = timeout(Duration::from_secs(5), runing()).await;
    match result {
        Ok(_) => println!("任务在超时时间内完成"),
        Err(_) => println!("任务超时"),
    }
}
fn main() {
    begin();
}