use time;
// 定义备忘录结构体
#[derive(Debug)]
struct Memorandum {
    // 使用i64存储时间戳
    date: i64, 
    event: String,
}
fn main() {
    // 获取当前时间戳
    let now_local = time::OffsetDateTime::now_local();
    let now = now_local.unwrap().unix_timestamp();
    // 创建备忘录实例
    let mut memos = vec![
        Memorandum {
            date: now,
            event: "学习Rust".to_string(),
        },
        Memorandum {
            date: now + 7250,
            event: "继续学习Rust".to_string(),
        },
        Memorandum {
            date: now + 9070,
            event: "晚了，洗洗睡吧，不然秃头了".to_string(),
        },
        Memorandum {
            date: now + 3460,
            event: "休息了，顺便吃顿饭".to_string(),
        },
    ];
    // 按时间排序
    memos.sort_by(|a, b| a.date.cmp(&b.date));
    // 输出排序结果
    for memo in &memos {
        // 时间戳转换字符串日期格式
        println!(
            "备忘时间：{:?}，你要做 {}",
            time::OffsetDateTime::from_unix_timestamp(memo.date).unwrap(),
            memo.event
        );
    }
}