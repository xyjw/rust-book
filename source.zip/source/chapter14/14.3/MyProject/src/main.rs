use time;
use time::macros::*;
// 设置时间格式
use time::format_description::well_known::Iso8601;
use time::format_description::well_known::Rfc2822;
use time::format_description::well_known::Rfc3339;
use time::format_description::well_known::iso8601;
fn main() {
    // 自定义字符串格式
    let format = format_description!("[year]/[month]/[day] [hour]:[minute]:[second]");
    // 获取当前时间
    let local_time = time::OffsetDateTime::now_local().unwrap();
    // 以内置的字符串格式输出时间
    let t1 = local_time.format(&Iso8601::DATE_TIME).unwrap();
    println!("以内置的字符串格式输出时间：{}",t1);
    // 以自定义字符串格式输出时间
    let t1 = local_time.format(&format).unwrap();
    println!("以自定义字符串格式输出时间：{}",t1);
}