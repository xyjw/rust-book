use time;
use time::macros::*;
fn main() {
    // 时间戳转换为时间格式
    let d1 = time::OffsetDateTime::from_unix_timestamp(1735282614);
    let res = d1.unwrap();
    println!("时间戳转换为时间格式：{:?}", res);
    // 时间戳转换为字符串格式
    let format = format_description!("[year]/[month]/[day] [hour]:[minute]:[second]");
    println!("时间戳转换为字符串：{}", res.format(format).unwrap());
    // 将整数转换为时分秒
    let t1 = time::Time::from_hms(6,30,30);
    println!("整数转换为时分秒：{}",t1.unwrap().to_string());
    
    // 字符串格式转为时间格式
    // 字符串格式转为日期时分秒
    let format = format_description!(
        "[year]/[month]/[day] [hour]:[minute]:[second] [offset_hour \
             sign:mandatory]:[offset_minute]:[offset_second]"
    );
    let t1 = time::OffsetDateTime::parse("2025/01/01 06:30:30 +06:07:08", format);
    println!("字符串格式转为日期时分秒：{:?}",t1.unwrap());
    // 字符串格式转为时分秒
    let format = format_description!("[hour]:[minute]:[second]");
    let t1 = time::Time::parse("06:30:30", format);
    println!("字符串格式转为时分秒：{:?}",t1.unwrap());
    // 字符串格式转为日期
    let format = format_description!("[year]/[month]/[day]");
    let d1 = time::Date::parse("2025/01/01", format);
    println!("字符串格式转为日期：{:?}",d1.unwrap());

    // 不同时间格式转换时间戳
    // 时间格式PrimitiveDateTime转换时间戳
    let d1 = datetime!(2025-06-06 06:06:06);
    let res = d1.assume_offset(offset!(UTC)).unix_timestamp();
    println!("时间格式PrimitiveDateTime转换时间戳：{:?}", res);
    // 时间格式OffsetDateTime转换时间戳
    let d2 = time::OffsetDateTime::now_utc();
    let res = d2.unix_timestamp();
    println!("时间格式OffsetDateTime转换时间戳：{:?}", res);
}