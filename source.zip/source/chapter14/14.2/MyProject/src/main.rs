use time;
fn main() {
    // 获取本地时间
    let t1 = time::OffsetDateTime::now_local().unwrap();
    // 获取当前时间的日期
    let d = t1.date();
    println!("当前时间的日期为：{:?}", d);
    // 获取当前时间的年份
    let y = t1.year();
    println!("当前时间的年份为：{:?}", y);
    // 获取当前时间的月份
    let month = t1.month();
    println!("当前时间的月份为：{:?}", month);
    // 获取当前时间的天数
    let day = t1.day();
    println!("当前时间的天数为：{:?}", day);
    // 获取当前时间的周数
    let week = t1.monday_based_week();
    println!("当前时间的周数为：{:?}", week);
    // 获取当前时间的小时
    let hour = t1.hour();
    println!("当前时间的小时为：{:?}", hour);
    // 获取当前时间的分钟
    let minute = t1.minute();
    println!("当前时间的分钟为：{:?}", minute);
    // 获取当前时间的秒数
    let second = t1.second();
    println!("当前时间的秒数为：{:?}", second);
    // 获取当前时间的毫秒
    let ms = t1.millisecond();
    println!("当前时间的毫秒为：{:?}", ms);
    // 获取当前时间的微妙
    let msc = t1.microsecond();
    println!("当前时间的微秒为：{:?}", msc);
}