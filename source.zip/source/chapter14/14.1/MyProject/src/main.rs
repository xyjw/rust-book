use time;
fn main() {
    // 获取当前UTC时间
    let t1 = time::OffsetDateTime::now_utc();
    println!("获取当前UTC时间：{}", t1.to_string());
    // 获取本地时间
    let t2 = time::OffsetDateTime::now_local().unwrap();
    println!("获取本地时间：{}", t2.to_string());
    let c1 = time::OffsetDateTime::unix_timestamp(t1);
    println!("现在时间的秒级时间戳：{}", c1);
    let c2 = time::OffsetDateTime::unix_timestamp_nanos(t1);
    println!("现在时间的纳秒级时间戳：{}", c2);
}