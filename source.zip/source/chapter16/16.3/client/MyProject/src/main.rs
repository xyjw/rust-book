use std::net::UdpSocket;
use std::io;

fn main() -> io::Result<()> {
    // 随机绑定客户端端口
    let socket = UdpSocket::bind("127.0.0.1:0")?;
    // 连接到服务器
    socket.connect("127.0.0.1:7878")?;
    println!("已连接到服务器！输入消息并按回车发送");
	println!("输入1则退出服务");
    loop {
        // 发送消息
        let mut input = String::new();
        // 从标准输入读取内容写入变量input
        io::stdin().read_line(&mut input)?;
        // 输入1退出服务
        if input == "1".to_string(){
            break;
        }
        // 发送数据给服务端
        socket.send(input.as_bytes())?;
        println!("已发送: {}", input.trim());
        // 接收响应数据和服务端地址
        let mut buf = [0; 1024];
        let (bytes, server_addr) = socket.recv_from(&mut buf)?;
        // 响应数据转为字符串格式
        let res = String::from_utf8_lossy(&buf[..bytes]);
        // 输出响应数据
        println!("收到来自 {} 的消息: {}", server_addr, res);
    }
    Ok(())
}