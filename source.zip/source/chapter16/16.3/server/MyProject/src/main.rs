use std::net::UdpSocket;
use std::io;

fn main() -> io::Result<()> {
    // 绑定到本地地址的 7878 端口
    let socket = UdpSocket::bind("127.0.0.1:7878")?;
    println!("UDP服务器运行在：127.0.0.1:7878");
    loop {
        // 缓冲区用于接收数据
        let mut buf = [0; 1024];
        // 接收数据和客户端地址
        let (bytes_read, client_addr) = socket.recv_from(&mut buf)?;
        let request = String::from_utf8_lossy(&buf[..bytes_read]);
        println!("收到来自 {} 的消息: {}", client_addr, request);
        // 将数据原样返回给客户端
        let res = format!(
            "HTTP/1.1 200 OK\r\nContent-Length:{}\r\nEcho:{}",
            request.len(),
            request
          );
        socket.send_to(res.as_bytes(), client_addr)?;
        println!("已发送数据给 {}", client_addr);
    }
}