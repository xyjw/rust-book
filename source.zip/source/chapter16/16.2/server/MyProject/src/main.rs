use std::net::{TcpListener, TcpStream};
use std::io::{Read, Write};
use std::thread;
fn handle_client(mut stream: TcpStream) {
    println!("新连接: {}", stream.peer_addr().unwrap());
    // 死循环监控客户端的请求
    loop {
        // 从TCP连接对象stream（即TcpStream）读取客户端发送数据
        // 数据加载到变量buffer
        let mut buffer = [0; 1024];
        match stream.read(&mut buffer) {
            Ok(bytes_read) => {
                // 变量buffer等于0，说明连接断开
                if bytes_read == 0 {
                    // 连接已关闭
                    println!("连接断开: {}", stream.peer_addr().unwrap());
                    return;
                }
                // 变量buffer非空时，读取客户端数据
                let request = String::from_utf8_lossy(&buffer[..]);
                println!("客户端数据：{}", request);
                // 根据接收数据生成回复
                let res = format!(
                    "HTTP/1.1 200 OK\r\nContent-Length: {}\r\nEcho: {}",
                    request.len(),
                    request
                );
                // 将数据响应给客户端
                if let Err(e) = stream.write_all(res.as_bytes()) {
                    println!("响应失败: {}", e);
                    return;
                }
            }
            Err(e) => {
                println!("读取失败: {}", e);
                return;
            }
        }
    }
}
fn main() -> std::io::Result<()> {
    // 绑定到本地地址的7878端口
    let listen = TcpListener::bind("127.0.0.1:7878")?;
    println!("服务器运行在 127.0.0.1:7878");
    // 接收进入的连接
    for stream in listen.incoming() {
        match stream {
            Ok(stream) => {
                // 为每个连接创建新线程
                thread::spawn(|| {
                    // 接收和处理连接
                    handle_client(stream);
                });
            }
            Err(e) => {
                println!("连接失败: {}", e);
            }
        }
    }
    Ok(())
}

