use std::io::{self, Read, Write};
use std::net::TcpStream;
use std::thread;
use std::time::Duration;

fn main() -> io::Result<()> {
    // 连接到服务器
    let mut stream = TcpStream::connect("127.0.0.1:7878")?;
    println!("已连接到服务器！输入消息并按回车发送。");
    // 循环读取用户输入并发送到服务器
    loop {
        let mut input = String::new();
        // 从标准输入读取内容写入变量input
        io::stdin().read_line(&mut input)?;
        // 发送数据到服务器
        // 数据以字节格式传递
        stream.write_all(input.trim().as_bytes())?;
        println!("已发送: {}", input.trim());
        // 等待服务器响应
        thread::sleep(Duration::from_millis(100));
        // 从TCP连接stream（即TcpStream）读取服务端响应数据
        let mut buffer = [0; 1024]; 
        match stream.read(&mut buffer) {
            Ok(bytes_read) => {
                // 变量buffer为空时，说明连接断开
                if bytes_read == 0 {
                    println!("连接已关闭");
                    break;
                }
                // 变量buffer非空时，读取服务端数据，转化为字符串格式
                let res = String::from_utf8_lossy(&buffer[..bytes_read]);
                println!("收到响应: {}", res);
            }
            Err(e) => {
                println!("读取错误: {}", e);
                break;
            }
        }
    }
    Ok(())
}