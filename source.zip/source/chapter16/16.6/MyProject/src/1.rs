use std::io::{Read, Write};
use std::net::TcpStream;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    // 建立连接
    let mut stream = TcpStream::connect("httpbin.org:80")?;

    // 构建 HTTP 请求数据
    let request = concat!(
        "GET /get HTTP/1.1\r\n",
        "Host: httpbin.org\r\n",
        "User-Agent: Rust/Std\r\n",
        "Connection: close\r\n",
        "\r\n"
    );

    // 发送请求
    stream.write_all(request.as_bytes())?;

    // 读取响应
    let mut buffer = Vec::new();
    stream.read_to_end(&mut buffer)?;
    let response = String::from_utf8_lossy(&buffer);

    // 分割响应头和响应内容
    if let Some((headers, body))=response.split_once("\r\n\r\n"){
        println!("Headers:\n{}\n\nBody:\n{}", headers, body);
    } else {
        println!("Full response:\n{}", response);
    }
    Ok(())
}
