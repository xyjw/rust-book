use std::{
    io::{Read, Write},
    net::{TcpListener, TcpStream},
    fs,
    thread,
};

// 发送HTML首页响应
fn response_index(stream: &mut TcpStream) {
    // 读取HTML文件内容
    let contents = fs::read("src/static/index.html").unwrap();
    // 构造HTTP响应头
    let headers = format!(
        "HTTP/1.1 200 OK\r\n\
        Content-Type: text/html\r\n\
        Content-Length: {}\r\n\r\n",
        contents.len()
    );
    // 发送响应头和内容
    stream.write_all(headers.as_bytes()).expect("响应头异常");
    stream.write_all(&contents).expect("文件异常");
    stream.flush().expect("请求刷新失败！");
}

// 发送文件下载响应
fn response_file(stream: &mut TcpStream) {
    // 设置要下载的文件名
    let filename = "image.jpg";
    // 读取文件内容
    let files = match fs::read("src/static/image.jpg") {
        Ok(content) => content,
        Err(_) => {
            // 文件不存在时返回404
            response_404(stream);
            return;
        }
    };
    // 构造下载响应头
    let headers = format!(
        "HTTP/1.1 200 OK\r\n\
        Content-Type: application/octet-stream\r\n\
        Content-Disposition: attachment; filename=\"{}\"\r\n\
        Content-Length: {}\r\n\r\n",
        filename,
        files.len()
    );
    // 发送响应数据
    stream.write_all(headers.as_bytes()).expect("响应头异常");
    stream.write_all(&files).expect("文件异常");
    stream.flush().expect("请求刷新失败！");
}

// 发送404未找到响应
fn response_404(stream: &mut TcpStream) {
    // 读取HTML文件内容
    let contents = fs::read("src/static/404.html").unwrap();
    // 构造HTTP响应头
    let headers = format!(
        "HTTP/1.1 404 Not Found\r\n\
        Content-Type: text/html\r\n\
        Content-Length: {}\r\n\r\n",
        contents.len()
    );
    // 发送响应数据
    stream.write_all(headers.as_bytes()).expect("响应头异常");
    stream.write_all(&contents).expect("文件异常");
    stream.flush().expect("请求刷新失败！");
}

// 处理客户端连接
fn handle_connection(mut stream: TcpStream) {
    // 创建1KB的缓冲区读取请求数据
    let mut buffer = [0; 1024];
    stream.read(&mut buffer).expect("请求读取失败！");
    // 将请求数据转换为字符串便于解析
    let request = String::from_utf8_lossy(&buffer[..]);
    // 获取请求的第一行（例如 "GET / HTTP/1.1"）
    let request_line = request.lines().next().unwrap_or("");
    // 分割请求行获取请求路径
    let path = request_line.split_whitespace().nth(1).unwrap_or("");
    // 根据请求路径路由处理
    match path {
        "/" => response_index(&mut stream),
        "/download" => response_file(&mut stream),
        _ => response_404(&mut stream),
    }
}

fn main() {
    // 绑定到本地8080端口，创建TCP监听器
    let listener = TcpListener::bind("127.0.0.1:8080").expect("端口连接失败");
    println!("Server listening on http://127.0.0.1:8080");
    // 持续处理传入的连接请求
    for stream in listener.incoming() {
        match stream {
            Ok(stream) => {
                // 为每个连接创建新线程处理
                thread::spawn(|| {
                    handle_connection(stream);
                });
            }
            Err(e) => {
                println!("Connection failed: {}", e);
            }
        }
    }
}