use reqwest;
use std::collections::HashMap;

#[tokio::main]
async fn main() -> Result<(),Box<dyn std::error::Error>> {
    // 异步模式发送请求
    let url = "https://httpbin.org/post";
    // 创建HTTP客户端
    let client = reqwest::Client::new();
    // 设置请求参数
    let params = [("foo", "bar"), ("baz", "quux")];
    // 设置JSON数据
    let mut map = HashMap::new();
    map.insert("lang", "rust");
    map.insert("body", "json");
    // 设置文件上传
    let form = reqwest::multipart::Form::new()
        .text("name", "Tim")
        .file("file", "src/favicon.ico").await?;
    // 调用body发送请求主体
    // 调用form发送表单数据
    // 调用json发送JSON数据
    // 调试过程中建议只使用一种请求参数类型
    let res = client
        .post(url)
        .body("the body is sent") // 请求主体
        .form(&params) // 表单数据
        .multipart(form) // 表单数据，用于文件上传
        .json(&map) // 发送JSON数据
        .send()
        .await?; // 发送异步请求
    // 输出响应内容
    println!("Status: {:?}", res.status());
    println!("body = {:?}", res.text().await?);
    Ok(())
}
