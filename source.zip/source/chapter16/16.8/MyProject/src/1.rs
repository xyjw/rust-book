use reqwest;
fn main() {
    // 同步模式发送请求
    let url = "https://httpbin.org/get";
    let res = reqwest::blocking::get(url).unwrap();
    // 输出响应内容
    println!("Status: {:?}", res.status());
    println!("body = {:?}", res.text().unwrap());
}