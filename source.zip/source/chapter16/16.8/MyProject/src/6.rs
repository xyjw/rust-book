use reqwest;
use reqwest::Proxy;
#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // 异步模式发送请求
    let url = "https://httpbin.org/get";
    // 创建客户端，设置代理
    // Proxy::http使用HTTP代理
    // Proxy::https使用HTTPS代理，basic_auth()设置认证
    // Proxy::all支持所有代理协议
    // SOCKS5代理需要在Cargo.toml开启socks
    let client = reqwest::Client::builder()
        .proxy(Proxy::http("http://127.0.0.1:1080")?)
        .proxy(Proxy::https("http://127.0.0.1:1080")?
            .basic_auth("username", "password"))
        .proxy(Proxy::all("socks5://127.0.0.1:1080")?)
        .build()?;
    // 发送请求
    let res = client
        .get(url)
        .send()
        .await?;
    // 输出响应内容
    println!("Status: {:?}", res.status());
    println!("body = {:?}", res.text().await?);
    Ok(())
}