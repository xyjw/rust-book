use reqwest;
use reqwest::header;
#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // 异步模式发送请求
    let url = "https://httpbin.org/get";
    // 创建支持Cookie持久化的客户端
    let client = reqwest::Client::builder()
        .cookie_store(true) // 启用 Cookie 存储
        .build()?;
    // 设置自定义Cookie
    // 多个Cookie用分号分隔
    let res = client
        .get(url)
        .header(header::COOKIE, "session_id=hyx; u=666")
        .send()
        .await?; // 发送异步请求
    // 输出响应内容
    println!("Status: {:?}", res.status());
    println!("body = {:?}", res.text().await?);
    Ok(())
}