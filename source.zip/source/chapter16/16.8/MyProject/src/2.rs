use reqwest;
#[tokio::main]
async fn main()->Result<(),Box<dyn std::error::Error>>{
    // 异步模式发送请求
    let url = "https://httpbin.org/get";
    let res = reqwest::get(url).await?;
    // 输出响应内容
    println!("Status: {:?}", res.status());
    println!("body = {:?}", res.text().await?);
    Ok(())
}
