use reqwest;
use tokio::fs::File;
use tokio::io::AsyncWriteExt;

#[tokio::main]
async fn main() -> Result<(),Box<dyn std::error::Error>> {
    // 异步模式发送请求
    let url = "https://httpbin.org/image/jpeg";
    let res = reqwest::get(url).await?;
    // 创建文件
    let filename = "file.jpeg";
    let mut file = File::create(filename).await?;
    // 写入内容
    let content = res.bytes().await?;
    file.write_all(&content).await?;
    Ok(())
}