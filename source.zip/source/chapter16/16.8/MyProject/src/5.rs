use reqwest;
use tokio::time::Duration;
#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // 异步模式发送请求
    let url = "https://httpbin.org/get";
    // 创建客户端，设置超时
    // 使用异步方式，延时由tokio::time::Duration设置时间
    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(10))
        .build()?;
    // 发送请求
    let res = client
        .get(url)
        .send()
        .await?;
    // 输出响应内容
    println!("Status: {:?}", res.status());
    println!("body = {:?}", res.text().await?);
    Ok(())
}