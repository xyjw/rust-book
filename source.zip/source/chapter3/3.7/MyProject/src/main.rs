fn main() {
    // 创建元组，并初始化成员值
    let mut x: (i32, f64, char, bool) = (500, 6.4, 'A', false);
    // 修改成员值
    x.0 = 666;
    x.3 = true;
    // 使用 . 访问成员
    println!("元组第一个成员值：{}", x.0);
    println!("元组第二个成员值：{}", x.1);
    println!("元组第三个成员值：{}", x.2);
    println!("元组第四个成员值：{}", x.3);
    // 解构赋值，将成员值分别赋值给不同变量
    let (y, z) = (777, 'B');
    println!("变量y的值：{}", y);
    println!("变量z的值：{}", z);
}