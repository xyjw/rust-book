fn main() {
    let a = 10;
    // 关系运算符
    let r = a == 20;
    println!("10是否等于20：{}", r);

    // if判断条件语句
    if a > 0 {
        println!("if的判断条件为true");
    }
    
    // while循环语句
    while a > 0 {
        println!("while循环为true");
        break;
    }
}