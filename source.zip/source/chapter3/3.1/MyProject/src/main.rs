
fn main(){
    let n1: i8 = 120;
    let n2: i16 = 1314;
    let n3: i32 = 30000;
    let n4: i64 = 15645645613456465;
    let n5: u32 = 4294967000;
    println!("{}", n1);
    println!("{}", n2);
    println!("{}", n3);
    println!("{}", n4);
    println!("{}", n5);
}

