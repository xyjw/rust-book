// fn main() {
//     // 浮点型转字符串
//     let float: f64 = 66.66;
//     // 使用format!()转换字符串
//     let str1: String = format!("{}", float);
//     println!("使用format!()转换字符串：{}", str1);
//     // 使用to_string()转换字符串
//     let str2: String = float.to_string();
//     println!("使用to_string()转换字符串：{}", str2);
// }

// fn main() {
//     let str = "66.66";
//     // 使用parse()将字符串转换为浮点型f64
//     let float: Result<f64, _> = str.parse();
//     // 处理可能的错误
//     match float {
//         Ok(num) => println!("字符串转浮点型：{}", num),
//         Err(e) => println!("转换错误：{}", e),
//     }
// }


fn main() {
    let str = "66.66";
    // 使用parse()将字符串转换为浮点型f64
    let float = str.parse::<f64>().unwrap();
    println!("字符串转浮点型：{}", float)
}