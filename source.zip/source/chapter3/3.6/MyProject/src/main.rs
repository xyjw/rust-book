fn main() {
    let a: char = 'z';
    let b: char = 'ℤ';
    let c: char = '😻';
    println!("字符a的值：{}", a);
    println!("字符b的值：{}", b);
    println!("字符c的值：{}", c);
}