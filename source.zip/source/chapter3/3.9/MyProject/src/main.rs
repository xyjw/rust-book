// fn main() {
//     // 整型转浮点型
//     let int: u32 = 6;
//     let float: f64;
//     float = int as f64;
//     println!("整型转浮点数：{}", float + 1.1);

//     // 浮点型转整型
//     let float: f64 = 6.6;
//     let int: u32;
//     int = float as u32;
//     println!("浮点型转整型：{}", int + 3);
// }

fn main() {
    // 浮点型转整型
    let float: f64 = 66666.6;
    let int: u8 ;
    int = float as u8;
    println!("浮点型转整型：{}", int);
}
