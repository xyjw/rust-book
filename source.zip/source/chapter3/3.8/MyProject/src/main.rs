fn main() {
    // 创建数组，并初始化成员值
    let mut x: [u32; 3] = [67, 69, 666];
    // 修改成员值
    x[0] = 167;
    x[1] = 169;
    // 使用 . 访问成员
    println!("数组第一个成员值：{}", x[0]);
    println!("数组第二个成员值：{}", x[1]);
    println!("数组第三个成员值：{}", x[2]);
    // 解构赋值，将成员值分别赋值给不同变量
    let [y, z, zz] = x;
    println!("变量y的值：{}", y);
    println!("变量z的值：{}", z);
    println!("变量zz的值：{}", zz);
    // 遍历数组  
    for &element in &x {  
        println!("成员值：{}", element);  
    }  
    // 使用枚举器来遍历索引和值
    for (i, v) in x.iter().enumerate() {  
        println!("索引：{}，成员值：{}", i, v);  
    }  
}
