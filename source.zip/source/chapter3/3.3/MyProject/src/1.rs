fn main() {  
    // f32的取值范围  
    let f32_max = std::f32::MAX;  
    let f32_min = std::f32::MIN;  
    println!("f32的最大值：{:e}", f32_max);
    println!("f32的最小值：{:e}", f32_min);
    // f64的取值范围  
    let f64_max = std::f64::MAX;
    let f64_min = std::f64::MIN;
    println!("f64的最大值：{:e}", f64_max);
    println!("f64的最小值：{:e}", f64_min);
}
