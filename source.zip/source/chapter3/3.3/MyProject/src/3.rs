fn main() {
    // 定义f64类型浮点数
    let a = 1.1;
    // 定义f64类型浮点数
    let b = 2.2;
    // 执行运算并保留两位小数点
    let res = format!("{:.2}", a + b);
    // 输出结果
    println!("a + b = {}", res)
}