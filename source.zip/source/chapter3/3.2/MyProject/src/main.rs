// fn main() {
//     // 十进制转十进制字符串 => 27
//     let res: String = format!("{}", 27);
//     println!("{}", res);
//     // 十进制转二进制字符串 => 0b11011
//     let res: String = format!("{:#b}", 27);
//     println!("{}", res);
//     // 十进制转八进制字符串 => 0o33
//     let res: String = format!("{:#o}", 27);
//     println!("{}", res);
//     // 十进制转小写十六进制字符串 => 0x1b
//     let res: String = format!("{:#x}", 27);
//     println!("{}", res);
//     // 十进制转大写十六进制字符串 => 0x1B
//     let res: String = format!("{:#X}", 27);
//     println!("{}", res);
//     // 十进制转不带前缀的十六进制字符串 => 1b
//     let res: String = format!("{:x}", 27);
//     println!("{}", res);
//     // 十进制转使用0填充二进制字符串，宽度为10 => 0b00011011
//     let res: String = format!("{:#010b}", 27);
//     println!("{}", res);
// }

// fn main() {
//     // 二进制 => 0b11011 转十进制字符串
//     let res: String = format!("{}", 0b11011);
//     println!("{}", res);
//     // 八进制 => 0o33 转十进制字符串
//     let res: String = format!("{}", 0o33);
//     println!("{}", res);
//     // 小写十六进制 => 0x1b 转十进制字符串
//     let res: String = format!("{}", 0x1b);
//     println!("{}", res);
//     // 大写十六进制 => 0x1B 转十进制字符串
//     let res: String = format!("{}", 0x1B);
//     println!("{}", res);
//     // 使用0填充二进制，宽度为10 => 0b00011011 转十进制字符串
//     let res: String = format!("{}", 0b00011011);
//     println!("{}", res);
// }

fn main() {
    // 二进制字符串转换十进制整型
    let res = u32::from_str_radix("11011", 2).unwrap();
    println!("{}", res);
    // 八进制字符串转换十进制整型
    let res = u32::from_str_radix("33", 8).unwrap();
    println!("{}", res);
    // 十进制字符串转换十进制整型
    let res = ("99").parse::<u32>().unwrap();
    println!("{}", res);
}