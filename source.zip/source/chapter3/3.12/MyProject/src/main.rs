use std::io;
fn main() {
    println!("请输入两个数字和一个运算符（+、-、*、/）：");
    println!("请按照 '数字1 操作符 数字2' 格式输入！");
    // 获取用户输入
    let mut input = String::new();
    let _ = io::stdin().read_line(&mut input);
    
    // 假设输入格式为 "数字1 操作符 数字2"
    // 将字符串以空格分割并存入动态数组
    let parts: Vec<&str> = input.trim().split_whitespace().collect();
    // 数组长度不等于3，说明输入有误
    if parts.len() != 3 {
        println!("格式错误，按照'数字1 操作符 数字2'格式输入！");
        return;
    }
    // 获取数组第一个和第三个的数字，并转换为浮点数
    let num1 = parts[0].parse::<f64>().expect("第一个数字无效");
    let num2 = parts[2].parse::<f64>().expect("第二个数字无效");
    // 使用match语句对运算符号匹配，执行相应计算
    let result = match parts[1] {
        "+" => num1 + num2,
        "-" => num1 - num2,
        "*" => num1 * num2,
        "/" => {
            if num2 == 0.0 {
                println!("除数不能为0！！！");
                return;
            }
            num1 / num2
        },
        _ => {
            println!("未知的操作符：{}", parts[1]);
            return;
        }
    };
    println!("计算：{} {} {} = {}", num1,parts[1],num2,result);
}