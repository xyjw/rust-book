// fn main() {
//     // 整型转字符串
//     let int: i32 = 666;
//     // 使用format!()转换字符串
//     let str1: String = format!("{}", int);
//     println!("使用format!()转换字符串：{}", str1);
//     // 使用to_string()转换字符串
//     let str2: String = int.to_string();
//     println!("使用to_string()转换字符串：{}", str2);
// }

// fn main() {
//     let str = "42";
//     // 使用parse()将字符串转换为整型u32
//     let int: Result<u32, _> = str.parse();
//     // 处理可能的错误
//     match int {
//         Ok(num) => println!("字符串转整型：{}", num),
//         Err(e) => println!("转换错误：{}", e),
//     }
// }


fn main() {
    let str = "42";
    // 使用parse()将字符串转换为整型u32
    let int = str.parse::<u32>().unwrap();
    println!("字符串转整型：{}", int)
}