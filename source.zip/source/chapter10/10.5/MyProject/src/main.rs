use std::rc::Rc;
use std::cell::RefCell;
fn main() {
    // 创建不可变的动态数组
    let v: Vec<i32> = vec![1, 2, 3];
    // 创建一个包含整数数组的Rc<RefCell<Vec<i32>>>
    let rc1: Rc<RefCell<Vec<i32>>> = Rc::new(RefCell::new(v));
    // 克隆Rc智能指针，用于创建多个所有者
    let rc2: Rc<RefCell<Vec<i32>>> = rc1.clone();
    // 输出rc1计数
    println!("rc1计数：{}", Rc::strong_count(&rc1));
    // 在代码块里面修改数据
    {
        let mut borrow_mut = rc1.borrow_mut();
        borrow_mut[0] = 666;
        println!("rc1的数据为：{:?}", borrow_mut);
    }
    // 在另一个所有者访问数据
    {
        let borrow = rc2.borrow();
        println!("从rc2读取数据：{:?}", borrow);
    }
    // 在另一个所有者新增数据
    {
        let mut borrow_mut = rc2.borrow_mut();
        borrow_mut.push(5);
        println!("从rc2新增数据：{:?}", borrow_mut);
    }
}