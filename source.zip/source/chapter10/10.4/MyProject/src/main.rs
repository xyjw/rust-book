use std::rc::Rc;
// 定义结构体
#[derive(Debug)]
#[warn(dead_code)]
struct List {
    val: i32,
    next: Option<Rc<List>>,
}

fn main() {
    // 定义节点10
    let l10 = Rc::new(List{val: 10, next: None});
    // 定义链表a，包含节点5、10
    let a = Rc::new(List{val: 5, next: Some(l10)});
    // 输出链表a的数据
    println!("链表a的数据：{:?}", a);
    // 输出链表a计数
    println!("第一次输出链表a计数：{}", Rc::strong_count(&a));
    // 定义链表b，包含节点3、5、10
    let b = Rc::new(List{val: 3, next: Some(Rc::clone(&a))});
    // 输出链表b的数据
    println!("链表b的数据：{:?}", b);
    // 输出链表a计数
    println!("第二次输出链表a计数：{}", Rc::strong_count(&a));
    // 使用代码块定义链表b
    {
        // 定义链表c，包含节点4、5、10
        let c = Rc::new(List{val: 4, next: Some(Rc::clone(&a))});
        // 输出链表c的数据
        println!("链表c的数据：{:?}", c);
        // 输出链表a计数
        println!("第三次输出链表a计数：{}", Rc::strong_count(&a));
    }
    // 输出链表a计数
    println!("第四次输出链表a计数：{}", Rc::strong_count(&a));
}