fn main() {
    // 定义变量x
    let x = 5;  
    // 将引用转换为原始指针
    let ptr: &i32 = &x;
    // 从指针变量ptr获取指针指向的值
    println!("指针指向的值：{}", *ptr);
    // 输出指针指向的内存地址
    println!("指针指向的内存地址：{:p}", ptr);
}