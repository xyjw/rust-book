fn main() {
    // 定义不可变变量x
    let x = 5;
    // 创建不可变裸指针
    let ptr: *const i32 = &x as *const i32;
    // 输出裸指针
    unsafe {
        println!("不可变裸指针指向的值：{}", *ptr);
        println!("不可变裸指针指向的内存地址：{:p}", ptr);
    }
    
    // 定义可变变量y
    let mut y = 5;
    // 创建可变裸指针
    let ptr1  = &mut y as *mut i32;
    unsafe {
        // 修改裸指针指向的值
        *ptr1 = 10;
        // 输出裸指针
        println!("可变裸指针指向的值：{}", *ptr1);
        println!("可变裸指针指向的内存地址：{:p}", ptr1);
    }
}