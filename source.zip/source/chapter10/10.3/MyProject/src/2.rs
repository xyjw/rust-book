// 定义节点对象
struct Node {
    val: i32,
    next: Option<Box<Node>>
}

fn main() {
    // 创建节点
    let n1 = Node{val: 1, next: None};
    let n2 = Node{val: 2, next: Some(Box::new(n1))};
    let n3 = Node{val: 3, next: Some(Box::new(n2))};
    let n4 = Node{val: 4, next: Some(Box::new(n3))};
    let n5 = Node{val: 5, next: Some(Box::new(n4))};
    // 创建枚举变量
    let mut header = Some(Box::new(n5));
    // 从枚举变量开始遍历，即从链表的头结点开始遍历
    while let Some(n) = header {
        println!("节点数据为：{}", n.val);
        println!("节点数据所在内存地址为：{:p}", n);
        header = n.next;
    }
}