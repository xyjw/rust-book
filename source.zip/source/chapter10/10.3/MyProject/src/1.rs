fn main() {
    // 定义Box<T>智能指针
    let box1 = Box::new(42);
    println!("Box<T>智能指针指向的值：{}", *box1);
    println!("Box<T>智能指针指向的内存地址：{:p}", box1);
}
