use rand::Rng;
use std::io;

fn main() {
    // 用户输入数字
    let mut my_nums = Vec::new();
    for i in 0..7 {
        println!("请输入第{}位号码：", i + 1);
        let mut input = String::new();
        io::stdin().read_line(&mut input).expect("读取失败");
        let num: i32 = input.trim().parse().expect("请输入数字");
        my_nums.push(num);
    }
    println!("你选到的号码分别为：{:?}", my_nums);
    // 生成随机数部分 (存储裸指针)
    let mut result = Vec::new();
    let mut rng = rand::thread_rng();
    while result.len() < 7 {
        let num = rng.gen_range(1..=36);
        // 判断随机产生数据是否存在于动态数组
        let exists = result.iter().any(|ptr: &Box<i32>| **ptr == num );
        if !exists {
            // 定义Box<T>智能指针
            let num_box = Box::new(num);
            // 写入动态数组
            result.push(num_box);
        }
    }
    // 打印开奖结果
    for (i, ptr) in result.iter().enumerate() {
        println!("第{}位号码为：{}", i + 1, *ptr);
    }
    // 兑奖逻辑
    for ptr in result {
        // 获取指针指向的值
        let num = *ptr;
        // 是否匹配用户输入数字
        if my_nums.contains(&num) {
            println!("号码 {} 选中了", num);
        }
    }
}