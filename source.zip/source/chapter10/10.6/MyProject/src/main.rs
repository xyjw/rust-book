use std::rc::{Rc, Weak};  
fn main() {
    // 定义强引用计数的智能指针
    let rc1: Rc<i32> = Rc::new(666);
    // 从强引用计数的智能指针创建弱引用计数智能指针
    let wc1: Weak<i32> = Rc::downgrade(&rc1);
    // 调用Rc::strong_count()输出强引用计数
    println!("第一次强引用计数：{}", Rc::strong_count(&rc1));
    // 调用Rc::weak_count()输出弱引用计数
    println!("第一次弱引用计数：{}", Rc::weak_count(&rc1));
    // 调用upgrade()升级为强引用，用于访问数据
    if let Some(rc2) = wc1.upgrade() {
        println!("第二次强引用计数：{}", Rc::strong_count(&rc1));
        println!("指针的数据值为：{}", *rc2);
    } else {
        // 原始数据已经被销毁
        println!("原始数据已经被销毁");
    };
    // 调用Rc::strong_count()输出强引用计数
    println!("第三次强引用计数：{}", Rc::strong_count(&rc1));
    // 调用Rc::weak_count()输出弱引用计数
    println!("第二次弱引用计数：{}", Rc::weak_count(&rc1));
}