use serde::{Deserialize, Serialize};
use std::fs::OpenOptions;
use std::io::{self, BufReader, BufWriter, Write};
use std::path::Path;

// 使用 serde 实现序列化和反序列化
#[derive(Debug, Serialize, Deserialize)]
struct Student {
    id: i32,
    name: String,
    age: i32,
    grade: String,
    major: String,
}

// 使用Result类型处理可能的错误
fn data_process(style: &str, students: &[Student]) -> Result<Vec<Student>, Box<dyn std::error::Error>> {
    // 读取JSON文件
    let path = Path::new("src/data.json");
    let mut result = Vec::new();
    // 匹配当前操作类型
    match style {
        "read" => {
            if path.exists() {
                // 读取数据
                let file = OpenOptions::new()
                    .read(true)
                    .open(path)?;
                let reader = BufReader::new(file);
                result = serde_json::from_reader(reader)?;
            }
        }
        "write" => {
            // 写入数据
            let file = OpenOptions::new()
                .write(true)
                .create(true)
                .truncate(true)
                .open(path)?;
            let writer = BufWriter::new(file);
            serde_json::to_writer(writer, students)?;
        }
        // 返回异常信息
        _ => return Err("Invalid operation".into()),
    }
    Ok(result)
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    loop {
        println!("欢迎来到学生信息管理系统");
        println!("查询请按1, 新增请按2, 删除请按3, 退出请按4：");
        let mut input = String::new();
        io::stdin().read_line(&mut input)?;
        let choice: i32 = input.trim().parse().unwrap_or(0);
        // 匹配用户输入的功能选项
        match choice {
            // 查询数据
            1 => {
                let data = data_process("read", &[])?;
                if data.is_empty() {
                    println!("暂无数据");
                    continue;
                }
                // 匹配第二次用户输入的功能选项
                println!("查询全部请按1, 查询某个学生请按2：");
                input.clear();
                io::stdin().read_line(&mut input)?;
                let query_type: i32 = input.trim().parse().unwrap_or(0);
                match query_type {
                    // 查询全部学生
                    1 => {
                        for student in &data {
                            println!(
                                "学号：{}、姓名：{}、年龄：{}、年级：{}、专业：{}",
                                student.id, student.name, student.age, student.grade, student.major
                            );
                        }
                    }
                    // 查询某个学生
                    2 => {
                        println!("请输入学号查询：");
                        input.clear();
                        io::stdin().read_line(&mut input)?;
                        let id: i32 = input.trim().parse().unwrap_or(0);
                        // 从所有学生信息找出某个学生
                        if let Some(student) = data.iter().find(|s| s.id == id) {
                            println!(
                                "学号：{}、姓名：{}、年龄：{}、年级：{}、专业：{}",
                                student.id, student.name, student.age, student.grade, student.major
                            );
                        } else {
                            println!("未找到该学生");
                        }
                    }
                    _ => println!("无效选项"),
                }
            }
            // 添加数据
            2 => {
                // 实例化结构体
                let mut student = Student {
                    id: 0,
                    name: String::new(),
                    age: 0,
                    grade: String::new(),
                    major: String::new(),
                };
                println!("请输入学号：");
                input.clear();
                io::stdin().read_line(&mut input)?;
                student.id = input.trim().parse()?;
                // 读取现有数据检查重复
                let mut data = data_process("read", &[])?;
                if data.iter().any(|s| s.id == student.id) {
                    println!("学号已存在！");
                    continue;
                }
                // 提示用户输入并写入结构体对象
                println!("请输入姓名：");
                input.clear();
                io::stdin().read_line(&mut &mut student.name)?;
                student.name = student.name.trim().to_string();

                println!("请输入年龄：");
                input.clear();
                io::stdin().read_line(&mut input)?;
                student.age = input.trim().parse()?;

                println!("请输入年级：");
                input.clear();
                io::stdin().read_line(&mut &mut student.grade)?;
                student.grade = student.grade.trim().to_string();

                println!("请输入专业：");
                input.clear();
                io::stdin().read_line(&mut &mut student.major)?;
                student.major = student.major.trim().to_string();
                // 添加数据
                data.push(student);
                data_process("write", &data)?;
                println!("添加成功！");
            }
            // 删除数据
            3 => {
                // 获取全部学生数据
                let data = data_process("read", &[])?;
                // 获取需要删除学生的ID
                println!("输入学号删除学生信息：");
                input.clear();
                io::stdin().read_line(&mut input)?;
                let id: i32 = input.trim().parse()?;
                // 从全部学生数据过滤掉删除学生的ID
                let new_data: Vec<Student> = data.into_iter().filter(|s| s.id != id).collect();
                // 重新写入数据
                data_process("write", &new_data)?;
                println!("删除成功！剩余学生：{} 人", new_data.len());
            }
            // 退出
            4 => break,
            // 判断无效输入
            _ => println!("无效选项，请重新输入"),
        }
    }
    Ok(())
}