use std::fs;
use std::io;
use std::path::Path;
fn main() {
    // 创建单个文件夹
    let path = "static/a";
    // 在static创建文件夹a
    if let Err(e) = fs::create_dir(path) {
        // 文件夹已存在
        if e.kind() == io::ErrorKind::AlreadyExists {
            println!("文件夹已存在：{}", path);
        } else {
            // 文件夹创建失败
            eprintln!("文件夹创建失败：{}", e);
        }
    } else {
        // 文件夹创建成功
        println!("文件夹创建成功：{}", path);
    }
    
    // 递归创建多级文件夹
    let path1 = "static/b/b1/b2";
    // 对创建结果不做处理，如有需要请参考create_dir()的示例
    fs::create_dir_all(path1);

    // 遍历文件夹static
    match fs::read_dir("static") {
        Ok(entries) => {
        for entry in entries {
            match entry {
            Ok(entry) => {
                let p = entry.path();
                println!("子文件或子文件夹：{}", p.display());
            },
            Err(_e) => println!("遍历失败")
            }   
        } 
        },
        Err(_e) => println!("遍历失败")
    };
    // 删除单个文件夹
    fs::remove_dir("static/a");
    // 删除文件夹及其所有内容
    fs::remove_dir_all("static/b");
}