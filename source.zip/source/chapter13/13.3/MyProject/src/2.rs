use std::fs::{self, File, OpenOptions};
use std::io::{self, Read, Write};
use std::path::Path;

fn reads(path: &Path) -> Result<String, io::Error> {
    // 打开文件并将文件内容写入变量contents
    let mut file = File::open(path)?;
    let mut contents = String::new();
    file.read_to_string(&mut contents)?;
    Ok(contents)
}

fn writes(path: &Path, contents: &str) -> Result<(), io::Error> {
    // 判断文件是否存在
    // 文件存在则打开文件，并设置内容追加模式append=true
    // 不存在则新建文件
    if path.exists() {
        let mut file = OpenOptions::new()
        .append(true)
        .create(false)
        .open(path)?;
        file.write_all(contents.as_bytes())?;
    } else {
        let mut file = File::create(path)?;
        file.write_all(contents.as_bytes())?;
    }
    Ok(())
}

fn main() {
    // 创建文件
    let path = "static/c.txt";
    // 在static创建文件c.txt
    if let Ok(_) = File::create(path) {
        // 文件创建成功
        println!("文件c.txt创建成功：{}", path);
    } else {
        // 文件创建失败
        println!("文件c.txt创建失败：{}", path);
    }
    // 创建或打开文件并写入数据
    let path1 = Path::new("static/b.txt");
    let contents = "Hello, Rust!\n";
    match writes(path1, contents) {
        Ok(()) => println!("文件b.txt写入成功"),
        Err(e) => println!("文件b.txt写入失败：{}", e),
    }
    // 打开文件并读取数据
    let path2 = Path::new("static/a.txt");
    match reads(path2) {
        Ok(contents) => println!("文件a.txt内容为：{}", contents),
        Err(e) => println!("文件a.txt读取失败：{}", e),
    }
    // 复制文件
    // 将b.txt赋值到d.txt
    fs::copy(path1, Path::new("static/d.txt"));
    // 重命名文件
    // 将b.txt赋值到b1.txt
    fs::rename(path1, Path::new("static/b1.txt"));
    // 删除文件c.txt
    fs::remove_file(path);
    println!("文件c.txt删除了");
}