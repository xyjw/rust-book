use umya_spreadsheet;
use std::path::Path;
fn main() {
    // 获取Excel文件路径信息
    let file = Path::new("static/data.xlsx");
    // 读取Excel文件
    let mut book = umya_spreadsheet::reader::xlsx::read(file).unwrap();
    // 指定Excel的第一个表格Sheet
    let sheet = book.get_sheet_mut(&0).unwrap();
    // 修改或新增数据
    sheet.get_cell_mut("B2").set_value_number(20);
    sheet.get_cell_mut("A4").set_value("Tim");
    sheet.get_cell_mut("B4").set_value("21");
    sheet.get_cell_mut("C4").set_value("BeiJing");
    // 保存覆盖原有文件
    let _ = umya_spreadsheet::writer::xlsx::write(&book, file);
    // 新的Excel文件路径信息
    let file = Path::new("static/data1.xlsx");
    // 保存到新的文件
    let _ = umya_spreadsheet::writer::xlsx::write(&book, file);
}