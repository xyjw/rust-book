use umya_spreadsheet;
use std::path::Path;

fn main() {
    // 获取Excel文件路径信息
    let file = Path::new("static/data.xlsx");
    // 读取Excel文件
    let mut book = umya_spreadsheet::reader::xlsx::read(file).unwrap();
    // 读取Excel的第一个表格Sheet
    let sheet = book.get_sheet_mut(&0).unwrap();
    // // 读取A2的数据
    let a1 = sheet.get_cell_value("A2").get_value();
    let a1 = sheet.get_cell_value((1,2)).get_value();
    let a1 = sheet.get_cell_value((&1,&2)).get_value();
    println!("读取A2的数据：{}", a1);

    // 读取已有数据的区域范围
    // get_cell_collection():读取已有数据的区域范围，但数据无序
    // get_cell_collection_sorted():读取已有数据的区域范围
    for d in sheet.get_cell_collection_sorted() {
        let v = d.get_cell_value().get_value();
        println!("读取已有数据：{}", v);
    }

    // 按列读取数据，但数据无序
    // get_collection_by_column(column_num):读取某列数据
    // get_collection_by_column_to_hashmap(column_num):读取某列数据和序号
    for (i, c) in sheet.get_collection_by_column_to_hashmap(&1) {
        let v = c.get_cell_value().get_value();
        println!("第二列的序号为：{}，数据为：{}", i, v);
    }

    // 按行读取数据，但数据无序
    // get_collection_by_row(row_num):读取某行数据
    // get_collection_by_row_to_hashmap(row_num):读取某行数据和序号
    for (i, c) in sheet.get_collection_by_row_to_hashmap(&1) {
        let v = c.get_cell_value().get_value();
        println!("第二行的序号为：{}，数据为：{}", i, v);
    }
}