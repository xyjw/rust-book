use csv::{Writer, Error};
use std::fs::File;
use std::io::BufWriter;

fn writers() -> Result<(), Error> {
    // 创建CSV文件
    let file = File::create("static/2.csv")?;
    // 通过csv的from_writer写入文件
    // 文件以流方式写入并放进缓冲器，即BufWriter::new(file)
    let mut writer = Writer::from_writer(BufWriter::new(file));
    // 定义文件表头
    let headers = vec!["Name", "Age", "Occupation"];
    // 写入表头数据
    writer.write_record(headers.as_slice())?;
    // 定义文件内容
    let data = vec![
        vec!["Alice", "30", "Engineer"],
        vec!["Bob", "25", "Designer"],
        vec!["Charlie", "35", "Teacher"],
    ];
    // 写入内容数据
    for record in data {
        writer.write_record(record.as_slice())?;
    }
    // 刷新保存数据
    writer.flush()?;
    Ok(())
}

fn main() {
    writers();
}
