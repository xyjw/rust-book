use csv::{Reader, Error};
use std::fs::File;
use std::io::BufReader;

fn reads() -> Result<(), Error> {
    // 打开CSV文件
    let file = File::open("static/1.csv")?;
    // 通过csv的from_reader读取文件
    // 文件以流方式读取并写入缓冲器，即BufReader::new(file)
    let mut reader = Reader::from_reader(BufReader::new(file));
    // 遍历输出文件表头
    // 将从枚举Result获取枚举变体StringRecord
    let result = reader.headers()?;
    // 遍历输出每一列的表头
    for d in 0..result.len(){
        println!("第{}列的表头为：{}", d+1, result.get(d).unwrap());
    }
    // 遍历输出文件内容
    let mut rows = 1;
    for result in reader.records() {
        // 将从枚举Result获取枚举变体StringRecord
        let record = result?;
        // 遍历输出每一行的每一列数据
        for d in 0..record.len(){
            println!("第{}行的第{}列数据为：{}", rows, d+1, record.get(d).unwrap());
        }
        rows += 1;
    }
    Ok(())
}

fn main() {
    reads();
}