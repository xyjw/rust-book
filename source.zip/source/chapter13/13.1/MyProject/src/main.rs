use std::process::Command;
fn main() {
    // 执行ipconfig指令
    let op = Command::new("ipconfig").output().expect("进程异常");
    // 获取执行结果
    let stdout = String::from_utf8_lossy(&op.stdout);
    // 输出执行结果
    println!("指令执行结果：\n{}", stdout.trim());
}