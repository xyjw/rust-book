use std::path::Path;
fn main() {
    // 获取当前文件所在路径
    let current_dir = env!("CARGO_MANIFEST_DIR");
    println!("当前文件所在路径：{}", current_dir);

    // 将字符串路径信息转为路径对象
    // 字符串路径信息为相对路径
    let path = Path::new("static");
    println!("相对路径为：{}", path.display());

    // 将路径A与另一个路径B组合成一个新路径C
    let path1 = Path::new(current_dir).join("static");
    println!("新路径为：{}", path1.display());

    // 获取路径最末端的文件或文件夹，如果是文件则带有后缀名
    let p = Path::new("static/a.txt").file_name().unwrap();
    println!("路径末端目录信息：{}", p.to_string_lossy());

    // 获取路径最末端的文件或文件夹，如果是文件则不带后缀名
    let fp = Path::new("static/a.txt").file_stem().unwrap();
    println!("路径末端目录信息：{}", fp.to_string_lossy());

    // 获取文件的后缀名
    let fp = Path::new("static/a.txt").extension().unwrap();
    println!("获取文件后缀名为：{}", fp.to_string_lossy());

    // 获取上一级目录
    let fp = Path::new(current_dir).parent().unwrap();
    println!("获取上一级目录为：{}", fp.display());

    // 判断目录是否以XX开头
    let fb = Path::new(current_dir).starts_with("F:\\MyRust");
    println!("目录是否以F:\\MyRust开头：{}", fb);

    // 判断目录是否以XX结尾
    let fb = Path::new(current_dir).ends_with("MyProject");
    println!("目录是否以MyProject结尾：{}", fb);

    // 遍历目录的所有文件或文件夹
    for f in path.read_dir().expect("出错啦") {
        if let Ok(f) = f {
            // 输出文件或文件夹所在路径
            println!("文件所在路径：{}", f.path().display());
        }
    }
}