use serde_json;
use serde_json::json;
fn main() {
    // 一个&str类型的JSON数据
    let data = r#"
        {
            "name": "Lily",
            "age": 20,
            "address": ["China", "ShangHai"]
        }"#;
    // JSON字符串转换成serde_json::Value枚举对象
    let mut v: serde_json::Value = serde_json::from_str(data).unwrap();
    // 修改数据
    v["age"] = json!(22);
    // 输出数据
    println!("name is {}",v["name"]);
    println!("age is {}",v["age"]);
    println!("address is {} {}",v["address"][0],v["address"][1]); 
}