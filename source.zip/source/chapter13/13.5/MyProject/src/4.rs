use serde::{Deserialize,Serialize};
use serde_json::json;
// 定义结构体
#[derive(Deserialize, Debug, Serialize)]
struct Person {
    name: String,
    age: i32,
    address: Vec<String>
}
fn main() {
    // 实例化结构体
    let p = Person{name: "Tom".to_string(), age: 22, 
					address: vec!["China".to_string(), 
								"BeiJing".to_string()]};

    // 使用宏json!将结构体转为serde_json::Value
    let j = json!(p);
    println!("{:#?}", j);
    // 使用serde_json::from_value将serde_json::Value转为结构体
    let p1: Person = serde_json::from_value(j).unwrap();
    // 输出数据
    println!("{:#?}", p1);
    println!("name is {}",p1.name);
    println!("age is {}",p1.age);
    println!("address is {} {}", p1.address[0], p1.address[1]);
}