use serde::Deserialize;
use serde_json;
use std::error::Error;
use std::fs::File;
use std::io::BufReader;
use std::path::Path;
// 定义结构体
#[derive(Deserialize, Debug)]
struct Person {
    name: String,
    age: i32,
    address: Vec<String>
}
// 自定义函数
fn read_file(p : &Path) -> Result<Person, Box<dyn Error>> {
    // 打开文件
    let file = File::open(p)?;
    // 文件以流方式读取并写入缓冲器，即BufReader::new(file)
    let reader = BufReader::new(file);
    // 将文件内容转换为serde_json::Value枚举对象
    // let p: serde_json::Value = serde_json::from_reader(reader)?;
    // 将文件内容转换为结构体Person的实例化对象
    let p: Person = serde_json::from_reader(reader)?;
    // 函数返回值
    Ok(p)
}
fn main() {
    // 获取文件路径对象
    let f = Path::new("static/data.json");
    // 调用自定义函数并返回JSON数据
    let p = read_file(f).unwrap();
    // 输出结构体对象Person
    println!("{:#?}", p);
    // 输出数据
    println!("name is {}",p.name);
    println!("age is {}",p.age);
    println!("address is {} {}", p.address[0], p.address[1]);
}