use serde::{Serialize, Deserialize};
use serde_json;
// 定义结构体
#[derive(Serialize, Deserialize)]
struct Person {
    name: String,
    age: i32,
    address: Vec<String>
}
fn main() {
    // 实例化结构体
    let p = Person{name: "Tom".to_string(), age: 22, address: vec!["China".to_string(), "BeiJing".to_string()]};
    // 结构体序列化转为JSON字符串
    let s = serde_json::to_string(&p).unwrap();
    // 输出数据
    println!("{}",s);
}