use std::io;  

fn main() {
   println!("输入你的年龄：");
   let mut age_input = String::new();
   io::stdin().read_line(&mut age_input)
      .expect("输入异常");
   let age_str = age_input.trim();
   let age = age_str.parse::<i32>()
      .expect("请输入正确的数字");
   println!("输入你的体重（kg）：");
   let mut weight_input = String::new();
   io::stdin().read_line(&mut weight_input)
      .expect("Failed to read weight input");
   let weight_str = weight_input.trim();
   let weight = weight_str.parse::<i32>()
      .expect("请输入正确的数字");
   println!("你的年龄为{}", age);
   // 使用if语句进行条件判断
   if age < 10 {
      if weight < 15 {
         println!("体重值为{}, 偏轻", weight);
      } else if weight >= 15 && weight < 30 {
         println!("体重值为{}, 正常", weight);
      } else {
         println!("体重值为{}, 偏重", weight);
      }
   } else if age >= 15 && age <= 30 {
      if weight < 40 {
         println!("体重值为{}, 偏轻", weight);
      } else if weight >= 40 && weight < 60 {
         println!("体重值为{}, 正常", weight);
      } else {
         println!("体重值为{}, 偏重", weight);
      }
   } else {
      if weight < 60 {
         println!("体重值为{}, 偏轻", weight);
      } else if weight >= 60 && weight < 80 {
         println!("体重值为{}, 正常", weight);
      } else {
         println!("体重值为{}, 偏重", weight);
      }
   }
}