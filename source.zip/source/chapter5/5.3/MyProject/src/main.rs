fn main() {  
   let x = 2;  
   let y = if x > 3 { x*2 } else { if x == 3 { x*3 } else { x*4 } };  
   println!("变量y的值为：{}", y);  
}