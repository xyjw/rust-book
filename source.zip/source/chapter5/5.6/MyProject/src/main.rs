fn main() {
   let mut count = 1;
   while count < 11 {
      println!("当前自然数：{}", count);
      // 修改变量，用于下次循环条件判断
      count += 1;
   }
}