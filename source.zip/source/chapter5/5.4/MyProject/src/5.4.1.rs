use std::io;
fn main() {
   println!("输入婴儿月份：");
   let mut input = String::new();
   io::stdin().read_line(&mut input)
      .expect("输入异常");
   // 去除换行符
   let month = input.trim();
   // 尝试将字符串转换为整数
   let month = month.parse::<i32>()
      .expect("请输入正确的数字");
   match month {
      1 => {
        println!("一个月男婴身高为48.2-52.8厘米，体重3.6-5.0千克。女婴身高47.7-52.0厘米，体重为2.7-3.6千克。")
      },
      2 => {
        println!("二个月男婴身高为52.1-57.0厘米，体重为4.3-6.0千克。女婴身高51.2-55.8厘米，体重为3.4-4.5千克。")
      },
      3 => {
        println!("三个月男婴身高为55.5-60.7厘米，体重为5.0-6.9千克。女婴身高54.4-59.2厘米，体重为4.0-5.4千克。")
      },
      _ => {
        println!("其它月份......")
      },
  }
}