use std::io;
fn main() {
   println!("输入你的体重（kg）：");
   let mut input = String::new();
   io::stdin().read_line(&mut input)
      .expect("输入异常");
   // 去除换行符
   let weight_str = input.trim();
   // 尝试将字符串转换为整数
   let weight = weight_str.parse::<i32>()
      .expect("请输入正确的数字");
   match weight {
      x if x < 40 => println!("体重值为{}, 偏轻", x),
      x if x >= 40 && x <= 70 => println!("体重值为{}, 正常", x),  
      _ => println!("体重值为{}, 偏重", weight),
  }
}