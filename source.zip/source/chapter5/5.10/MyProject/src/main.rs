use rand::Rng;
use std::collections::HashMap;
use std::io;
fn main() {
    // 创建随机生成器
    let mut rng = rand::thread_rng();
    // 创建集合
    let mut products = HashMap::new();
    // 创建动态数组
    let mut sample = Vec::new();
    // 获取用户输入的产品数量
    println!("请输入检测产品数量：");
    let mut input = String::new();
    io::stdin().read_line(&mut input).expect("数据读取失败");
    // 将产品数量转换为整型格式
    let num = input.trim().parse().expect("请输入有效的数字");
    // 根据产品数量生成产品编号
    // 编号从1开始，以集合存储
    for i in 1..=num {
        products.insert(i, i);
    }
    // 计算样品数量
    // 在产品数量的1/2~1/4范围选择样品数量
    let runs = rng.gen_range(num / 4..=num / 2);  
    // 随机抽取样品
    for _ in 0..runs {
        let n = rng.gen_range(1..=num);
        // 判断产品编号是否在产品中
        if products.contains_key(&n) {
            // 若存在则加入sample
            sample.push(n);
            // 产品已转为样品，应从products删除
            products.remove(&n);
        }
    }
    // 计算合格率
    let mut qualified = 0;
    for k in &sample {
        // 在1～100范围生成随机数
        let probability = rng.gen_range(1..=100);
        // 若随机数大于50，则视为产品合格
        if probability > 50 {
            // 样品合格数量自增加1
            println!("产品编号{}检测合格", k);
            qualified += 1;
        } else {
            // 若随机数小于等于50，则视为产品不合格
            println!("产品编号{}检测不合格", k);
        }
    }
    // 计算合格率（百分比表示）：样品合格数量 / 样品总数
    let rate = (qualified as f64) / (sample.len() as f64) * 100.0;
    println!("合格率：{:.2}%", rate);
}