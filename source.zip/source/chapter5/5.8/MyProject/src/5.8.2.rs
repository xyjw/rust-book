fn main() {
   // 'outer是最外层循环的标签
   'outer: for i in 0..3 {
       println!("外层循环的变量i：{}", i);
       for j in 0..5 {
           if j == 2 {
               // 跳出到标签为'outer'的循环
               break 'outer;
           }
           println!("内层循环的变量j：{}", j);
       }
   }
}