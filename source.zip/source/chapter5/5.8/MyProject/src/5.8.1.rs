fn main() {
   // loop循环使用break
   let mut count = 0;
   loop {
      if count == 2 {
         break;
      }
      println!("{}", count);
      count += 1;
   }
   // while循环使用break
   let mut count = 0;
   while count == 2 {
      println!("{}", count);
      count += 1;
   }
   // for循环使用break
   for i in (0..10).rev() {
      if i == 2 {
         break;
      }
      println!("{}", i);
   }
}