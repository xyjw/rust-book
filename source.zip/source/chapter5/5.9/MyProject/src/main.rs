fn main() {
   // loop循环使用continue
   let mut i = 0;
   loop {
       i += 1;
       if i >= 5 {
           break;
       }
       if i % 2 == 0 {
           // 跳过偶数
           continue;
       }
       println!("奇数为：{}", i);
   }
   // while循环使用continue
   let mut i = 0;
    while i <= 5 {
        i += 1;
        if i % 2 == 0 {
            // 跳过偶数  
            continue;
        }
        println!("奇数为：{}", i);
    }
   // for循环使用continue
   for i in 0..6 {
       if i % 2 == 0 {
           // 跳过偶数
           continue;
       }
       println!("奇数为：{}", i);
   }
}