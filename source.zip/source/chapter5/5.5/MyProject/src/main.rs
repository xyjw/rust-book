fn main() {
   let mut count = 0;
   loop {
      count += 1;
      println!("当前自然数：{}", count);
   if count >= 10 {
      // 当count达到10时，退出循环
      break;
   }
   }
}