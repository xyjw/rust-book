fn main() {
   // 使用..运算符，从0到4执行遍历
   for i in 0..5 {
      println!("{}", i);
   }
   // 从0到9执行遍历并设置步长，只循环0，2，4...
   for i in (0..10).step_by(2) {
      println!("{}", i);
   }
   // 将0到9倒转再循环
   for i in (0..10).rev() {
      println!("{}", i);
   }
}