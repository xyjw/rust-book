fn main() {
   let str1 = "Hello, world!";  
   for char in str1.chars() {  
      println!("{}", char);  
   }
}