fn main() {
   let arr = [1, 2, 3, 4, 5];
   for num in arr.iter() {
       println!("{}", num);
   }
   // 或者使用更简洁语法  
   for num in &arr {
       println!("{}", num);
   }
   let vec = vec![1, 2, 3, 4, 5];
   // 遍历动态数组
   for num in vec.iter() {
       println!("{}", num);
   }
   // 使用更简洁语法
   for num in &vec {
      println!("{}", num);
   }
   // 对于动态数组或其它迭代器对象，可以直接迭代
   for num in vec {
      println!("{}", num);
  }
}