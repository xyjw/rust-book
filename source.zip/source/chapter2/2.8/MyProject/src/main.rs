fn main(){
    let a = 8;
    let b = 5;
    println!("x大于y：{}", a > b);
    println!("x大于或等于y：{}", a >= b);
    println!("x小于y：{}", a < b);
    println!("x小于或等于y：{}", a <= b);
    println!("x等于y：{}", a == b);
    println!("x不等于y：{}", a != b);
}
