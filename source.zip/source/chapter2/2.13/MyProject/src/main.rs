use std::io;

fn main(){
    // 定义变量name、weight和height
    let mut name: String = String::new();
    let mut weight: String = String::new();
    let mut height: String = String::new();
    // 获取用户输入数据
    println!("请输入你的名字：");
    io::stdin()
        .read_line(&mut name)
        .expect("读取输入时发生错误");
    println!("请输入你的体重kg：");
    io::stdin()
        .read_line(&mut weight)
        .expect("读取输入时发生错误");
    println!("请输入你的身高cm：");
    io::stdin()
        .read_line(&mut height) 
        .expect("读取输入时发生错误");
    // 将变量weight和height转换浮点数
    // trim_end()去掉字符串末尾的空白字符或换行符等
    let w = weight.trim_end().parse::<f64>().unwrap();
    let mut h = height.trim_end().parse::<f64>().unwrap();
    // 单位换算，将cm换算成m
    h /= 100.0;
    // 计算BMI
    let result = w / (h * h);
    // 计算结果保留两位小数
    // 保留后数据为字符串，再转换浮点数
    let bmi = format!("{:.2}", result).parse::<f64>().unwrap();
    // 根据BMI判断身体状态
    if bmi < 18.5  {
        println!("你的BMI为{}，体重过轻", bmi);
    }else if 18.5 <= bmi && bmi < 24.0 {
        println!("你的BMI为{}，体重正常", bmi);
    }else if 24.0 <= bmi && bmi < 27.0 {
        println!("你的BMI为{}，体重过重", bmi);
    }else if 27.0 <= bmi && bmi < 30.0 {
        println!("你的BMI为{}，体重轻度肥胖", bmi);
    }else if 30.0 <= bmi && bmi < 35.0 {
        println!("你的BMI为{}，体重中度肥胖", bmi);
    }else {
        println!("你的BMI为{}，体重重度肥胖", bmi);
    }
}

