static MY_VAR: i32 = 42;
// 注意：静态变量默认是不可变的，但可以使用关键字`mut`声明它们为可变的。
// 由于Rust的线程安全保证，可变静态变量在实际使用中需要额外注意。
// 如果需要可变静态变量，并且能确保线程安全
// Rust鼓励使用安全的并发原语，如如Mutex、RwLock、Channel和Atomic类型。
static mut MY_MUT_VAR: i32 = 0; // 这是合法的，但通常不推荐
fn main() {
    println!("不可变静态变量：{}", MY_VAR);
    unsafe {  
    println!("可变静态变量：{}", MY_MUT_VAR);
    }
}


// use std::sync::Mutex;
// // 定义可变静态变量，数据类型为Mutex
// static MY_MUTEX_VAR: Mutex<i32> = Mutex::new(0);
// fn main() {  
//     // 使用互斥锁来保护对静态变量的访问
//     {
//         let mut lock = MY_MUTEX_VAR.lock().unwrap();
//         *lock = 42;
//     }
//     // 在另一个线程中访问它（为了简化，这里在同一个线程中演示）
//     {
//         let lock = MY_MUTEX_VAR.lock().unwrap();
//         println!("可变静态变量：{}", *lock);  
//     }
// }