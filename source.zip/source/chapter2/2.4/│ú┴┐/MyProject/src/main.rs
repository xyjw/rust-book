// 定义一个整型的常量
const MYINT: u32 = 100;
// 定义一个布尔型的常量
const MYBOOL: bool = false;
// 定义一个字符串常量
const MYSTR: &str = "Hello, world!";
// 定义一个元组常量
const TUPLE: (i32, i32) = (3, 4);
// 定义一个数组常量
const ARR: [i32; 5] = [1, 2, 3, 4, 5];
// 定义一个结构体常量
struct Point {
    x: i32,
    y: i32,
}
const MYSTRUCT: Point = Point { x: 0, y: 0 };
fn main() {
    // 使用常量
    println!("整型常量：{}", MYINT);
    println!("布尔型的常量：{}", MYBOOL);
    println!("字符串的常量：{}", MYSTR);
    println!("元组常量：({}, {})", TUPLE.0, TUPLE.1);
    println!("数组常量：{:?}", ARR);
    println!("结构体常量：({}, {})", MYSTRUCT.x, MYSTRUCT.y);
}
