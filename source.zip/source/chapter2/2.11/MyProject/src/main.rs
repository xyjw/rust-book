fn main(){
    // 对应二进制：0011 1100
    let a = 60;
    // 对应二进制：0000 1101
    let b = 13;
    let mut c;
    c = a & b;
    println!("c的十进制值为：{}", c);
    println!("c的二进制值为：{:b}", c);
    c = a | b;
    println!("c的十进制值为：{}", c);
    println!("c的二进制值为：{:b}", c);
    c = a ^ b;
    println!("c的十进制值为：{}", c);
    println!("c的二进制值为：{:b}", c);
    c = a << 2;
    println!("c的十进制值为：{}", c);
    println!("c的二进制值为：{:b}", c);
    c = a >> 2;
    println!("c的十进制值为：{}", c);
    println!("c的二进制值为：{:b}", c);
}