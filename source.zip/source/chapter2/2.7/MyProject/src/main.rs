fn main(){
    let a = 8;
    let b = 5;
    println!("加法运算符：{}", a+b);
    println!("减法运算符：{}", a-b);
    println!("乘法运算符：{}", a*b);
    println!("除法运算符：{}", a/b);
    println!("求余运算符：{}", a%b);
}
