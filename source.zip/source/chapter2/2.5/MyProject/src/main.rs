fn main() {
    // 定义变量w，不初始化赋值
    let w;
    w = 66;
    println!("变量w的值：{}", w);
    // 变量x是32位整数
    let x: i32 = 42;
    println!("变量x的值：{}", x);
    // Rust推断变量y是i32位整数，因为42是一个字面量整数
    let y = 42;
    println!("变量y的值：{}", y);
    // 声明并初始化多个变量
    let (a, b, c) = (1, "2", false);
    println!("变量a的值：{}", a);
    println!("变量b的值：{}", b);
    println!("变量c的值：{}", c);
}

// fn main() {
//     // 可变变量x是32位整数
//     let mut x = 42;
//     println!("变量x的值：{}", x);
//     // 修改变量值
//     x = 666;
//     println!("变量x的值：{}", x);
// }

// fn main() {
//     // 定义变量var
//     let var = 66;
//     {
//         // 再次定义变量var
//         // 代码块里隐藏了第一次定义的变量var
//         let var = 77;
//         println!("变量var的值：{}", var);
//     }
//     // 代码块结束，释放第二次定义变量var
//     // 编译器取回第一次定义的变量var
//     println!("变量var的值：{}", var);
// }
