fn main(){
    let (a,b,c,d) = (true, true, false, false);
    println!("a&&b的值为：{}", a && b);
    println!("a&&c的值为：{}", a && c);
    println!("c&&d的值为：{}", c && d);
    println!("a||b的值为：{}", a || b);
    println!("a||c的值为：{}", a || c);
    println!("c||d的值为：{}", c || d);
    println!("!a的值为：{}", !a);
    println!("!c的值为：{}", !c);
}
