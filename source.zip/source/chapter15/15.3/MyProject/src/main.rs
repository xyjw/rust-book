use rusqlite::{Connection, Result, Error, params};
use std::path::Path;
// 数据库连接
fn connect(db_path: &Path) -> Result<Connection, Error> {
    let conn = Connection::open(db_path)?;
    Ok(conn)
}
// 创建数据表
fn create_tb(conn: &Connection) {
    conn.execute(
    "CREATE TABLE if not exists person (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        age INTEGER
        )",
        params![],
    );
}
// 新增数据
fn insert(name: &str, age: i32, conn: &Connection) {
    conn.execute(
        "INSERT INTO person (name, age) VALUES (?1, ?2)",
        params![name, age],
    );
}
// 更新数据
fn update(name: &str, age: i32, conn: &Connection) {
    conn.execute(
        "UPDATE person SET age = ? WHERE name = ?",
        params![age, name],
    );
}
// 查询数据
fn query(conn: &Connection) -> Result<Vec<(i32,String,i32)>>{
    // 设置查询语句
    let mut stmt = conn.prepare("SELECT * FROM person")?;
    // 获取查询结果
    let person_iter = stmt.query_map([], |row| {
        Ok((row.get(0)?, row.get(1)?, row.get(2)?))
    })?;
    // 处理查询结果
    let mut persons = Vec::new();
    for p in person_iter {
        persons.push(p?);
    }
    Ok(persons)
}
// 删除数据
fn delete(id: i32, conn: &Connection) {
    conn.execute(
        "DELETE FROM person WHERE id = ?",
        params![id],
    );
}
// 事务处理
fn transact(conn: &mut Connection) {
    // 开启事务
    let tx = conn.transaction().unwrap();
    // 执行SQL语句
    tx.execute("INSERT INTO person (name, age) VALUES 
                (?1, ?2)", params!["Lily", 20]).unwrap();
    tx.execute("INSERT INTO person (name, age) VALUES 
                (?1, ?2)", params!["Tom", 25]).unwrap();
    tx.execute("UPDATE person SET age = age + 1 
                WHERE name = ?1", params!["Lily"]).unwrap();
    // 所有操作成功，提交事务
    tx.commit().unwrap();
}
fn main(){
    let db_path = Path::new("db\\sqlite.db");
    let mut conn = connect(db_path).unwrap();
    // 创建数据表
    create_tb(&conn);
    // 新增数据
    insert("Tim", 22, &conn);
    // 更新数据
    update("Tim", 18, &conn);
    // 查询数据
    let data = query(&conn);
    println!("{:?}", data.unwrap());
    // 删除数据
    delete(1,  &conn);
    // 事务处理
    transact(&mut conn)
}
