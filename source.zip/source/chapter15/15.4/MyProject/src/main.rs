use mysql::*;
use mysql::prelude::*;
use std::error::Error;
// 定义结构体
#[derive(Debug, PartialEq, Eq)]
struct Person {
    id: i32,
    name: String,
    age: i32,
}
// 数据库连接
fn connect(url: &str) -> PooledConn{
    let pool = Pool::new(url).unwrap();
    let mut conn = pool.get_conn().unwrap();
    return conn;
}
// 创建数据表
fn create_tb(conn: &mut PooledConn) {
    conn.query_drop(
    "CREATE TABLE if not exists person (
        id INTEGER PRIMARY KEY AUTO_INCREMENT,
        name TEXT NOT NULL,
        age INTEGER
        )");
}
// 新增数据
fn insert(name: &str, age: i32, conn: &mut PooledConn) {
    // 设置SQL语句
    let sql = "INSERT INTO person (name, age) VALUES (?, ?)";
    // 使用exec_drop执行SQL语句
    conn.exec_drop(sql, (name, age)).unwrap();
}
// 更新数据
fn update(name: &str, age: i32, conn: &mut PooledConn) {
    // 设置SQL语句
    let sql = "UPDATE person SET age = ? WHERE name = ?";
    // 使用exec_drop执行SQL语句
    conn.exec_drop(sql, (age, name)).unwrap();
}
// 查询数据
fn query(conn: &mut PooledConn){
    // 执行查询语句
    let res = conn.query_map("SELECT * FROM person", 
    |(id, name, age)|{
        Person {id, name, age}
    }).unwrap();
    println!("{:?}", res)
}
// 删除数据
fn delete(id: i32, conn: &mut PooledConn) {
    // 设置SQL语句
    let sql = "DELETE FROM person WHERE id = ?";
    // 使用exec_drop执行SQL语句
    conn.exec_drop(sql, (id,)).unwrap();
}
// 事务处理
fn transact(conn: &mut PooledConn) {
    // 开启事务
    let mut tx = conn.start_transaction(TxOpts::default()).unwrap();
    // 执行SQL语句
    tx.exec_drop("INSERT INTO person (name, age) VALUES (?, ?)", ("Lily", 20)).unwrap();
    tx.exec_drop("INSERT INTO person (name, age) VALUES (?, ?)", ("Tom", 25)).unwrap();
    tx.exec_drop("UPDATE person SET age = age + 1 WHERE name = ?", ("Lily",)).unwrap();
    // 所有操作成功，提交事务
    tx.commit().unwrap();
}
fn main() {
    let url = "mysql://root:1234@localhost:3306/test";
    let mut conn = connect(url);
    // 创建数据表
    create_tb(&mut conn);
    // 新增数据
    insert("Tim", 22, &mut conn);
    // 更新数据
    update("Tim", 18, &mut conn);
    // 查询数据
    query(&mut conn);
    // 删除数据
    delete(1,  &mut conn);
    // 事务处理
    transact(&mut conn);
}