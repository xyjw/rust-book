use redis::*;
// 创建数据库连接
fn connect(url: &str) -> Connection {
    let client = redis::Client::open(url).unwrap();
    let mut conn = client.get_connection().unwrap();
    return conn;
}
// 字符串类型的数据操作
fn str_data(conn: &mut Connection) {
    // 添加数据
    let _: () = conn.set("person1", "Tom").unwrap();
    let _: () = conn.set("person2", "Lily").unwrap();
    // 删除数据
    let _: () = conn.get_del("person2").unwrap();
    // 读取数据
    let name: String = conn.get("person1").unwrap();
    println!("字符串类型的person1值为：{}", name);
}
// 哈希类型的数据操作
fn hash_data(conn: &mut Connection) {
    // 添加数据
    let _: () = conn.hset("person_h", "Tom", 22).unwrap();
    let _: () = conn.hset("person_h", "Lily", 18).unwrap();
    // 删除数据
    let _: () = conn.hdel("person_h", "Lily").unwrap();
    // 读取数据
    let age: i32 = conn.hget("person_h", "Tom").unwrap();
    println!("哈希类型的Tom年龄为：{}", age);
}
// 列表的数据操作
fn list_data(conn: &mut Connection) {
    // 从列表的右边（尾部）添加数据
    let _: () = conn.rpush("person_l", "Tom").unwrap();
    // 从列表的左边（头部）添加数据
    let _: () = conn.lpush("person_l", "Lily").unwrap();
    // 从列表的左边（头部）读取并删除数据
    let name: Vec<String> = conn.blpop("person_l", 2.0).unwrap();
    println!("列表类型的person_l值为：{}", name[1]);
}
// 集合的数据操作
fn set_data(conn: &mut Connection) {
    // 添加一个或多个成员
    let _: () = conn.sadd("person_s", vec!["Tom", "Lily", "Tim"]).unwrap();
    // 移除并返回集合中的一个随机成员
    let _: () = conn.spop("person_s").unwrap();
    // 获取所有集合成员
    let name: Vec<String> = conn.smembers("person_s").unwrap();
    println!("集合类型的所有成员为：{:?}", name);
}
// 有序集合的数据操作
fn zset_data(conn: &mut Connection) {
    // 添加一个成员
    let _: () = conn.zadd("person_z", "Tom", 1.1).unwrap();
    // 添加多个成员
    let _: () = conn.zadd_multiple("person_z", &[(2.2, "Tim"), (6.6, "Lucy")]).unwrap();
    // 删除指定成员
    let _: () = conn.zrem("person_z", vec!["Tim"]).unwrap();
    // 读取范围内的成员
    let name: Vec<String> = conn.zrange("person_z", 0, 1).unwrap();
    println!("有序集合类型的范围内成员为：{:?}", name);
}
// 位图类型的数据操作
fn bit_data(conn: &mut Connection) {
    // 参数offset是二级制的位数偏移量，0代表从左边第一位算起
	// 参数value为布尔型，代表二级制的0和1
    let _: () = conn.setbit("person_b", 1, true).unwrap();
    let res: bool = conn.getbit("person_b", 2).unwrap();
    println!("获取位图类型数据某个偏移量的值：{}", res);
    // 删除位图类型数据
    let _: () = conn.del("person_b").unwrap();
}
// 流类型的数据操作
fn stream_data(conn: &mut Connection) {
    // 添加数据
    let _: () = conn.xadd("person_st", 1, &[("Tom", 22)]).unwrap();
    let _: () = conn.xadd("person_st", 2, &[("Tim", 18)]).unwrap();
    // 读取并删除所有数据
    let name: Option<streams::StreamRangeReply> = conn.xrange("person_st", "-", "+").unwrap();
    if let Some(reply) = name {
		for k in reply.ids {
			println!("读取流类型的所有数据：{:?}", k);
            // 删除数据
            let _: () = conn.xdel("person_st", &[k.id]).unwrap();
		}
	}
}
fn main() {
    let url = "redis://127.0.0.1/";
    let mut conn = connect(url);
    str_data(&mut conn);
    hash_data(&mut conn);
    list_data(&mut conn);
    set_data(&mut conn);
    zset_data(&mut conn);
    bit_data(&mut conn);
    stream_data(&mut conn);
}