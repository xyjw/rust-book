mod mydb;
use sea_orm::*;
use mydb::{prelude::*, *};
use futures::executor::block_on;
use futures::join;
// 创建数据库连接
async fn connect() -> DatabaseConnection  {
    let opt = ConnectOptions::new("mysql://root:1234@127.0.0.1:3306/test");
    let db = Database::connect(opt).await.unwrap();
    return db;
}
// 新增数据
async fn insert(db: DatabaseConnection) {
    // 创建动态数组
    let mut vec: Vec<person::ActiveModel> = Vec::new();
    // 创建数组
    let data = [("Tom".to_string(), 22), ("Tim".to_string(), 18)];
    // 循环数组创建person::ActiveModel对象并写入动态数组
    for d in data{
        vec.push(person::ActiveModel {
            name: ActiveValue::Set(d.0),
            age: ActiveValue::Set(Some(d.1)),
            ..Default::default()
        });
    }
    // insert_many是批量新增，insert是单条新增
    // 批量新增的数据类型为数组或动态数组
    // 单条新增的数据类型为person::ActiveModel
    Person::insert_many(vec).exec(&db).await.unwrap();
}
// 修改数据
async fn update(db: DatabaseConnection) {
    // 修改ID=1的数据，将Tom改为Lucy
    let p = person::ActiveModel {
        id: ActiveValue::Set(1),
        name: ActiveValue::Set("Lucy".to_owned()),
        ..Default::default()
    };
    let f = Person::find_by_id(1).one(&db).await.unwrap();
    if f != None{
        // update_many是批量修改，update是单条修改
        // 批量修改的数据类型为数组或动态数组
        // 单条修改的数据类型为person::ActiveModel
        Person::update(p).exec(&db).await.unwrap();
    } else {
        println!("ID等于1的数据不存在，修改失败")
    }
}
// 查询数据
async fn query(db: DatabaseConnection) {
    // 查询全部数据
    let data: Vec<person::Model> = Person::find().all(&db).await.unwrap();
    for d in data{
        println!("当前名称为：{}，年龄：{}", d.name, d.age.unwrap());
    }
    // 按条件查询
    // 如果多个条件，则调用多个filter()
    let data: Vec<person::Model> = Person::find()
        .filter(person::Column::Name.eq("Tim"))
        .all(&db).await.unwrap();
    for d in data{
        println!("当前名称为：{}，年龄：{}", d.name, d.age.unwrap());
    }
}
// 删除数据
async fn delete(db: DatabaseConnection) {
    let p = person::ActiveModel {
        id: ActiveValue::Set(1),
        ..Default::default()
    };
    let f = Person::find_by_id(1).one(&db).await.unwrap();
    if f != None{
        // 删除数据
        // delete_many是批量删除，delete是单条删除
        // 批量删除的数据类型为数组或动态数组
        // 单条删除的数据类型为person::ActiveModel
        Person::delete(p).exec(&db).await.unwrap();
    } else {
        println!("ID等于1的数据不存在，删除失败")
    }
}
// 执行程序
async fn run() -> Result<(), DbErr> {
    // 创建数据库连接
    let f = connect();
    let (db,) = join!(f);
    // 新增数据
    let f = insert(db.clone());
    let _ = join!(f);
    // 修改数据
    let f = update(db.clone());
    let _ = join!(f);
    // 查询数据
    let f = query(db.clone());
    let _ = join!(f);
    let f = delete(db.clone());
    let _ = join!(f);
    // 删除数据
    Ok(())
}
fn main() {
    let _ = block_on(run());
}