mod mydb;
use sea_orm::*;
use mydb::{prelude::*, *};
use std::io::{self, Write};
use tokio;
use chrono::Local;

// 创建数据库连接
async fn connect() -> Result<DatabaseConnection, DbErr>  {
    let opt = ConnectOptions::new("mysql://root:1234@127.0.0.1:3306/enterprise");
    let db = Database::connect(opt).await?;
    Ok(db)
}
// 创建新员工
async fn insert_employee(db: &DatabaseConnection) -> Result<(), DbErr> {
    // 创建空的用户对象
    let mut employee = user::ActiveModel {
        created_at: ActiveValue::Set(Some(Local::now().naive_local())),
        updated_at: ActiveValue::Set(Some(Local::now().naive_local())),
        ..Default::default()
    };
    // 获取用户输入
    println!("请输入名字：");
    let mut name = String::new();
    io::stdin().read_line(&mut name);
    // 将数据写入用户对象
    employee.name = ActiveValue::Set(Some(name.trim().to_string()));
    println!("请输入年龄：");
    let mut age = String::new();
    io::stdin().read_line(&mut age);
    employee.age = ActiveValue::Set(Some(age.trim().to_string()));
    println!("请输入职位：");
    let mut profession = String::new();
    io::stdin().read_line(&mut profession);
    employee.profession = ActiveValue::Set(Some(profession.trim().to_string()));
    println!("请输入所属组织编号：");
    let mut org = String::new();
    io::stdin().read_line(&mut org);
    let org_id = Some(org.trim().parse().unwrap_or(0));
    employee.organize_id = ActiveValue::Set(org_id);
    // 将用户对象employee写入数据库
    let result = user::Entity::insert(employee).exec(db).await?;
    println!("新员工添加成功，ID：{}", result.last_insert_id);
    Ok(())
}
// 删除员工
async fn delete_employee(db: &DatabaseConnection) -> Result<(), DbErr> {
    // 获取用户输入
    println!("请输入需要删除的员工姓名：");
    let mut name = String::new();
    io::stdin().read_line(&mut name);
    // 删除数据表数据
    let res = user::Entity::delete_many()
        .filter(user::Column::Name.eq(name.trim()))
        .exec(db)
        .await?;
    println!("已删除 {} 条记录", res.rows_affected);
    Ok(())
}
// 查询员工（带组织信息）
async fn query_employee(db: &DatabaseConnection) -> Result<(), DbErr> {
    // 查询所有用户
    let employees = user::Entity::find().all(db).await?;
    // 遍历输出每个用户信息
    for user in employees {
        // 查询用户所属组织架构
        let org_id = user.organize_id.unwrap();
        let org = organize::Entity::find_by_id(org_id).all(db).await?;
        let mut organize = String::new();
        if org.len() == 0 {
            organize = "暂无组织".to_string();
        } else {
            organize = org[0].name.clone().unwrap();
        }
        println!(
            "员工 {:?} 的职位：{:?}，所属组织：{:?}",
            user.name.clone().unwrap(),
            user.profession.clone().unwrap(),
            organize
        );
    }
    Ok(())
}
// 员工管理操作
async fn employee(db: &DatabaseConnection) -> Result<(), DbErr> {
    loop {
        // 在员工管理获取用户输入操作提示
        println!("新增员工请按1, 删除员工请按2, 查询员工请按3, 返回上级请按4：");
        let mut input = String::new();
        io::stdin().read_line(&mut input);
        let choice: i32 = input.trim().parse().unwrap_or(0);
        // 根据用户输入执行员工操作
        match choice {
            1 => insert_employee(&db).await?,
            2 => delete_employee(&db).await?,
            3 => query_employee(&db).await?,
            4 => break,
            _ => println!("请输入有效选项"),
        }
    }
    Ok(())
}
// 组织架构管理操作
async fn organization(db: &DatabaseConnection) -> Result<(), DbErr> {
    loop {
        println!("新增组织请按1, 删除组织请按2, 查询组织请按3, 返回上级请按4：");
        let mut input = String::new();
        io::stdin().read_line(&mut input);
        let choice: i32 = input.trim().parse().unwrap_or(0);
        // 根据用户输入执行组织架构操作
        match choice {
            1 => println!("功能尚未完善"),
            2 => println!("功能尚未完善"),
            3 => println!("功能尚未完善"),
            4 => break,
            _ => println!("请输入有效选项"),
        }
    }
    Ok(())
}
#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // 创建数据库连接
    let db = connect().await?;
    loop {
        // 提示用户输入
        println!("欢迎来到企业员工信息管理系统");
        println!("员工管理请按1, 组织架构管理请按2, 退出请按3：");
        let mut input = String::new();
        io::stdin().read_line(&mut input)?;
        let choice: i32 = input.trim().parse().unwrap_or(0);
        // 匹配用户输入
        match choice {
            1 => employee(&db).await?,
            2 => organization(&db).await?,
            3 => break,
            _ => println!("请输入有效选项"),
        }
    }
    Ok(())
}