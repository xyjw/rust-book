fn main() {  
    let s = "Hi,世界!";
    // 遍历字符
    for c in s.chars() {
        print!("{} ", c);
    }
    println!();
    // 遍历字节
    for b in s.as_bytes() {
        print!("{} ", b);
    }
    println!();

    // 使用枚举遍历字符
    for (i, c) in s.chars().enumerate() {
        println!("当前循环次数为：{}，遍历数据为：{}", i, c);
    }
    // 使用枚举遍历字节
    for (i, b) in s.as_bytes().into_iter().enumerate() {
        println!("当前循环次数为：{}，遍历数据为：{}", i, b);
    }
}
