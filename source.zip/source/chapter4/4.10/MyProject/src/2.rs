fn main(){
    // 创建空的动态数组
    let mut vec: Vec<i32> = Vec::new();
    // 写入数据
    vec.push(1);
    vec.push(2);
    vec.push(3);
    vec.push(4);
    vec.push(5);
    println!("动态数组：{:?}", vec);
    // 通过成员索引访问成员值
    let num = vec[0];
    println!("第一个成员是：{}", num);
    // 使用get()和成员索引访问成员值
    if let Some(d) = vec.get(2) {
        // 输出: 第三个成员是：3
        println!("第三个成员是：{}", d);
    } else {
        println!("索引无效");
    }
    // 遍历输出
    for element in &vec {
        println!("{}", element);
    }
    // 切片处理，截取部分数据
    let slice = &vec[1..3];
    for element in slice {
        println!(" 截取部分数据：{}", element);
    }
    // 通过索引值删除成员
    vec.remove(1);
    println!("动态数组：{:?}", vec);
    // 删除全部成员
    vec.clear();
    println!("动态数组：{:?}", vec);
    // 数组合并
    let v1: Vec<i32> = vec![4, 5];
    vec.extend(v1.iter());
    println!("数组合并：{:?}", vec)
}