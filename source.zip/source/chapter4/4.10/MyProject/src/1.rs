fn main(){
    // 使用new()创建空的动态数组
    let mut vec: Vec<i32> = Vec::new();
    // 写入数据
    vec.push(1);
    println!("{:?}", vec);

    // 使用with_capacity()创建
    let mut vec: Vec<i32> = Vec::with_capacity(5);
    // 写入数据
    vec.push(2);
    println!("{:?}", vec);

    // 使用宏vec!创建并初始化数据
    let vec: Vec<i32> = vec![1, 2, 3];
    println!("{:?}", vec);

    // 使用迭代器和collect()创建
    let vec: Vec<i32> = (1..=3).collect();
    println!("{:?}", vec);

    // 使用原生数组和collect()创建
    let slice: [i32; 3] = [1, 2, 3];
    let vec: Vec<i32> = slice.iter().cloned().collect();
    println!("{:?}", vec);

    // 使用原生数组和to_vec()创建
    let slice: [i32; 3] = [1, 2, 3];
    let vec: Vec<i32> = slice.to_vec();
    println!("{:?}", vec);

    // 使用双端队列VecDeque创建
    use std::collections::VecDeque;
    let deque: VecDeque<i32> = VecDeque::from([1, 2, 3]);
    let vec: Vec<i32> = Vec::from_iter(deque);
    println!("{:?}", vec);
}