// fn sub_index(s: &str, start: usize, length: usize) -> String {
//     // 字符序列
//     let chars = s.chars();
//     // 获取起始位置
//     let start_iter = chars.clone().skip(start);
//     // 从起始位置开始，根据截取长度截取数据
//     let sub_chars: Vec<char> = start_iter.take(length).collect();
//     // 返回截取结果
//     return sub_chars.iter().collect()
// }  

// fn main() {
//     let s = "hello,world";
//     // 截取前两个字符
//     let substring = sub_index(s, 1, 4);
//     println!("截取前两个字符：{}", substring);
// }

fn main(){
    // 截取方法1
    let str = "Hi,你好，这是Rust!";
    let substring = &str[0..5];
    println!("{}", substring);  // 输出 "Hi,你"
    // 截取方法2
    let str = "Hi,你好，这是Rust!";
    if let Some(substring) = str.get(0..5) {
        println!("{}", substring);  // 输出 "Hi,你"
    }
}