fn main() {
    let s = "apple,banana,cherry";
    // 使用逗号作为分割符
    let iter = s.split(",");
    // 使用for循环遍历迭代对象
    for fruit in iter {
        println!("{}", fruit);
    }
    // 分割后使用collect()存储在动态数组
    let fruits: Vec<&str> = s.split(",").collect();
    for fruit in fruits {
        println!("{}", fruit);
    }
}