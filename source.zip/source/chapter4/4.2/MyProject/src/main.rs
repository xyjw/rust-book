fn main(){
    let str = "hello";
    // 单个字符串格式化
    let new_str = format!("{} world", str);
    println!("单个字符串格式化：{}", new_str);
    // 多个字符串格式化
    let name = "Rust";
    let new_str = format!("{} world，this is {}", str, name);
    println!("多个字符串格式化：{}", new_str);
    // 设置命名参数
    let new_str = format!("{s} world，this is {n}", s=str, n=name);
    println!("设置命名参数：{}", new_str);
    // 设置索引参数，从0开始
    let new_str = format!("{0} world，this is {1}", str, name);
    println!("设置索引参数：{}", new_str);
    // 格式化数字，保留两位小数
    let new_str = format!("Pi = {:.2}", 3.141592653589793);
    println!("格式化数字：{}", new_str);
    // 字符串格式居中对齐，总宽度为10
    let new_str = format!("居中对齐，总宽度为10：{:^10}", name);
    println!("字符串格式：{}", new_str);
    // 集合格式化
    let new_str = format!("数组：{:?}", [1, 2, 3, 4, 5]);
    println!("集合格式化：{}", new_str);
}
