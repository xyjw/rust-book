use std::collections::VecDeque;
fn main() {
    // 创建一个空的VecDeque
    let mut dq = VecDeque::new();
    // 在队列前端添加成员
    dq.push_front(1);
    dq.push_front(2);
    // 在队列末尾添加成员
    dq.push_back(3);
    dq.push_back(4);
    // 遍历队列
    for x in &dq {
        println!("{}", x);
    }
    // 获取队列末尾的成员
    println!("获取队列末尾的成员：{}", dq.back().unwrap());
    // 获取队列前端的成员
    println!("获取队列前端的成员：{}", dq.front().unwrap());
    // 移除并返回队列末尾的成员
    println!("移除并返回队列末尾的成员：{}", dq.pop_back().unwrap());
    // 移除并返回队列前端的成员
    println!("移除并返回队列前端的成员：{}", dq.pop_front().unwrap());
    // 判断成员是否存在
    let res = dq.contains(&66);
    println!("判断成员是否存在：{}", res);
    // 清空队列
    dq.clear();
    println!("{:?}", dq);
}