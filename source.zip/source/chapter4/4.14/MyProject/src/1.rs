use std::collections::VecDeque;

fn main() {
   // 创建一个空的VecDeque  
   let mut dq = VecDeque::new();
   println!("{:?}", dq);
   // 创建带初始化的VecDeque
   let mut dq = VecDeque::from([1, 2]);
   println!("{:?}", dq);
   // 通过动态数组转换VecDeque
   let dq: VecDeque<i32>=vec![0,1,2].into_iter().collect();
   println!("{:?}", dq);
}
