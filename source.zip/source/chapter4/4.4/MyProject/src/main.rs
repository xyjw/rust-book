use unicode_segmentation::UnicodeSegmentation;

fn main() {
    let str1: &str = "hello world";
    println!("英文内容的字符串长度：{}", str1.len());
    let str1: &str = "你好!";
    println!("中文内容的字符串长度：{}", str1.len());
    let c = UnicodeSegmentation::graphemes(str1, true).count();
    println!("中文内容的字符串长度：{}", c);
}