// use std::collections::BTreeMap;

// fn main() {
//    // 创建一个空的BTreeMap
//    let bm = BTreeMap::new();
//    println!("{:?}", bm);
//    // 创建带初始化的BTreeMap
//    let bm = BTreeMap::from([("tom", 1), ("lily", 2)]);
//    println!("{:?}", bm);
//    // 通过动态数组转换BTreeMap
//    let bm: BTreeMap<&str, i32>=vec![("tom", 1), ("lily", 2)].into_iter().collect();
//    println!("{:?}", bm);
// }

use std::collections::BTreeSet;

fn main() {
   // 创建一个空的BTreeSet
   // let bs = BTreeSet::new();
   // println!("{:?}", bs);
   // 创建带初始化的BTreeSet
   let bs = BTreeSet::from([5, 2, 7, 1]);
   println!("{:?}", bs);
   // 通过动态数组转换BTreeSet
   let bs: BTreeSet<i32>=vec![3, 7, 1, 4].into_iter().collect();
   println!("{:?}", bs);
}





