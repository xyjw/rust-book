// use std::collections::BTreeMap;

// fn main() {
//    // 创建一个空的BTreeMap
//    let mut bm = BTreeMap::new();
//    // 新增或修改成员
//    bm.insert("Tom", 18);
//    bm.insert("Lily", 22);
//    bm.insert("Mary", 20);
//    bm.insert("Mary", 25);
//    println!("{:?}", bm);
//    // 遍历成员
//    for x in &bm {
//       println!("键等于：{:?}", x.0);
//       println!("值等于：{:?}", x.1);
//    }
//    // 访问成员
//    let age = bm["Lily"];
//    println!("Lily的年龄为：{}", age);
//    let age = bm.get("Mary").unwrap();
//    println!("Mary的年龄为：{}", age);
//    // 判断成员是否存在
//    let res = bm.contains_key("Tim");
//    println!("Tim在不在BTreeMap：{}", res);
//    // 清空BTreeMap
//    // remove()删除某个键值对
//    bm.remove("Tom");
//    // clear()删除全部数据
//    bm.clear();
// }

use std::collections::BTreeSet;

fn main() {
   // 创建一个空的BTreeSet
   let mut bs = BTreeSet::new();
   bs.insert(&66);
   bs.insert(&77);
   bs.insert(&67);
   println!("{:?}", bs);
   // 遍历BTreeSet
   for &num in &bs {
      println!("{}", num);
  }
  // 判断成员是否存在
  let res = bs.contains(&66);
  println!("判断66是否存在：{:?}", res);
  // 删除成员
  bs.remove(&66);
  println!("{:?}", bs);
  // 清空集合
  bs.clear();
  println!("{:?}", bs);
}