// fn main() {  
//     let original = "Hello, world!";  
//     let replaced = original.replace("world", "Rust");  
//     println!("{}", replaced);  // 输出: Hello, Rust!  
// }

use regex::Regex;
fn main() {
    // 创建一个正则表达式对象，匹配单词"World"
    let re = Regex::new("World").unwrap();
    let original = "Hello, World! World is beautiful";
    // 使用正则表达式的replace_all()进行替换
    let replaced = re.replace_all(&original, "Rust");
    println!("{}", replaced);  // 输出: Hello, Rust! Rust is beautiful
}