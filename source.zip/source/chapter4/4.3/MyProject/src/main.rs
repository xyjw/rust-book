// fn main() {
//     let str = "hello ";
//     // 使用format!拼接字符串
//     let new_str = format!("{}world", str);
//     println!("使用format!拼接字符串：{}", new_str);
//     // 使用运算符+拼接字符串
//     let str1 = "world";
//     let new_str = str.to_string() + &str1.to_string();
//     println!("使用运算符+拼接字符串：{}", new_str);
// }

fn main(){
    let mut str = String::from("hello ");
    // 使用format!拼接字符串
    let new_str = format!("{} world", str);
    println!("使用format!拼接字符串：{}", new_str);
    // 使用运算符+拼接字符串
    let str1 = String::from("world");
    let new_str = str.clone() + &str1;
    println!("使用运算符+拼接字符串：{}", new_str);
    // 使用push_str()拼接字符串
    str.push_str("world");
    println!("使用push_str()拼接字符串：{}", str);
    // 使用push()拼接字符串
    str.push('R');
    println!("使用push()拼接字符串：{}", str)
}