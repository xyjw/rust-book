use std::collections::LinkedList;

fn main() {
    // 创建带初始化的LinkedList
    let mut list: LinkedList<i32> = LinkedList::from([0,1,2]);
    // 在链表末尾添加成员
    list.push_back(1);
    list.push_back(2);
    // 在链表前端添加成员
    list.push_front(0);
    println!("{:?}", list);
    // 遍历链表
    for x in &list {
        println!("{}", x);
    }
    // 获取链表末尾的成员
    if let Some(tail) = list.back() {
        println!("获取链表末尾的成员：{}", tail);
    };
    // 获取链表前端的成员
    if let Some(head) = list.front() {
        println!("获取链表前端的成员：{}", head);
    }
    // 移除并返回链表末尾的成员
    if let Some(tail) = list.pop_back() {
        println!("移除并返回链表末尾的成员：{}", tail);
    }
    // 移除并返回链表前端的成员
    if let Some(head) = list.pop_front() {
        println!("移除并返回链表前端的成员：{}", head);
    }
    // 判断成员是否存在
    let res = list.contains(&66);
    println!("判断成员是否存在：{}", res);
    // 清空链表
    list.clear();
    println!("{:?}", list);
}
