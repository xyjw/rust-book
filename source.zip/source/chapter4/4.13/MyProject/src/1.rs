use std::collections::LinkedList;

fn main() {
    // 创建空的双向链表LinkedList
    let mut list = LinkedList::new();
	println!("{:?}", list);
    // 创建带初始化的LinkedList
    let mut list: LinkedList<i32> = LinkedList::from([0, 1, 2]);
	println!("{:?}", list);
    // 通过动态数组转换LinkedList
    let mut list: LinkedList<i32> = vec![0, 1, 2].into_iter().collect();
	println!("{:?}", list);
}