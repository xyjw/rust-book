// fn main(){
//     // 使用换行符
//     let str = "hello \n world";
//     println!("使用换行符：{}", str);
//     // 使用制表符
//     let str = "hello \t world";
//     println!("使用制表符：{}", str);
//     // 使用反斜杠
//     let str = "hello \\ world";
//     println!("使用反斜杠：{}", str);
//     // 使用双引号
//     let str = "hello \" world";
//     println!("使用双引号：{}", str);
//     // 使用单引号
//     let str = "hello \' world";
//     println!("使用单引号：{}", str);
//     // 使用回车符
//     let str = "hello \r world";
//     println!("使用回车符：{}", str);
// }

fn main() {
    // 从&str到String
    // 使用String::from()
    let str1: &str = "Hello, world!";
    let string1: String = String::from(str1);
    // 使用to_string()
    let string1: String = str1.to_string();
    // 使用to_owned()
    let string1: String = str1.to_owned();

    // 从String到&str
    let string1 = String::from("Hello, world!");
    let str1: &str = &string1;
}

fn main(){
    // 不使用换行符
    let str = r#"hello \n world"#;
    println!("不使用换行符：{}", str);
    // 不使用制表符
    let str = r#"hello \t world"#;
    println!("不使用制表符：{}", str);
    // 不使用反斜杠
    let str = r#"hello \\ world"#;
    println!("不使用反斜杠：{}", str);
    // 不使用双引号
    let str = r#"hello \" world"#;
    println!("不使用双引号：{}", str);
    // 不使用单引号
    let str = r#"hello \' world"#;
    println!("不使用单引号：{}", str);
    // 不使用回车符
    let str = r#"hello \r world"#;
    println!("不使用回车符：{}", str);
}