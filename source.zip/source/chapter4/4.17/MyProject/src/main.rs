use std::io;
fn main() {  
    let begin = "欢迎致电中国移动10086客服服务热线\n业务查询请按1，手机充值请按2，业务办理请按3，语音导航请按4，人工服务请按0";
    println!("{}", begin);
    // 输出服务提示
    println!("请选择您的服务内容：");
    // 获取用户输入
    let mut input = String::new();
    let _ = io::stdin().read_line(&mut input);
    // 将输入数据转换整型
    let input_int = input.trim().parse::<u32>().unwrap();
    // 判断服务选择
    match input_int {
        1 => {
            // 业务查询  
            println!("话费查询请按1，流量查询请按2，套餐业务查询请按3");
            // 获取用户输入
            let mut num_input = String::new();
            let _ = io::stdin().read_line(&mut num_input);
            // 将输入数据转换整型
            let num = num_input.trim().parse::<u32>().unwrap();
            match num {
                1 => {println!("您的话费余额为100元。")},
                2 => {println!("您的流量剩余100MB。")},
                3 => {println!("您的当前套餐为XXX。")},
                _ => {println!("未知选项，请重新选择。")},
            }
        },
        2 => {
            // 手机充值
            // 设置充值卡密码
            let code = "123abc";
            println!("请输入充值卡的密码并按#键结束：");
            // 获取用户输入
            let mut code_num_input = String::new();
            let _ = io::stdin().read_line(&mut code_num_input);
            // 将输入数据去掉“#”并去掉前后的空格或换行符
            let code_num = code_num_input.trim().replace("#", "");
            // 匹配用户输入和充值卡密码
            if code == code_num {
                println!("充值成功，您的余额为120元");
            } else {
                println!("充值失败，请输入正确的充值密码。");
            }
        },
        3 => {
            // 业务办理
            println!("业务办理服务");
        },
        4 => {
            // 语音导航
            println!("语音导航服务");
        },
        0 => {
            // 人工服务
            println!("人工服务");
        },
        _ => {
            println!("未知服务选项，请重新选择。");
        }
    }
}