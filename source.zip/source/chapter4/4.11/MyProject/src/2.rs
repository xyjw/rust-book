use std::collections::HashMap;
  
fn main() {
    // 创建HashMap并初始化
    let mut hp: HashMap<&str, i32> = HashMap::from([
        ("Alice", 18),
        ("Bob", 22),
        ("Charlie", 25),
    ]);
    
    // 新增或修改键值对
    hp.insert("Alice", 18);
    hp.insert("Bob", 22);
    hp.insert("Charlie", 25);

    // 访问成员
    let age = hp["Bob"];
    println!("Bob的年龄为：{}", age);
    let alice = hp.get("Alice");
    if let Some(age) = alice {
        println!("Alice的年龄为：{}", age);
    }

    // 遍历HashMap
    for (key, value) in &hp {
        println!("key等于：{}，value等于：{}", key, value);
    }

    // 删除键和对应的值
    hp.remove("Charlie");
    hp.clear();

    // 检查键是否存在
    let charlie = hp.contains_key("Charlie");
    println!("Charlie在不在HashMap：{}", charlie);
}