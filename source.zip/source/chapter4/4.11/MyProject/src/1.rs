use std::collections::HashMap; // 导入std::collections
  
fn main() {
    // 创建一个空的HashMap
    let mut hp = HashMap::new();
    // 创建HashMap并初始化
    let mut hp: HashMap<&str, i32> = HashMap::from([
        ("Alice", 18),
        ("Bob", 22),
        ("Charlie", 25),
    ]);
    
    // 使用原生数组转换创建一个HashMap
    let mut hp: HashMap<&str, i32> = [
        ("Alice", 18),
        ("Bob", 22),
        ("Charlie", 25),
    ].iter().cloned().collect();

    // 使用动态数组转换创建一个HashMap
    let mut hp: HashMap<&str, i32> = vec![
        ("Alice", 18),
        ("Bob", 22),
        ("Charlie", 25),
    ].into_iter().collect();
}
