use std::collections::BinaryHeap;

fn main() {
   // 创建一个空的BinaryHeap
   let bh = BinaryHeap::new();
   println!("{:?}", bh);
   // 创建带初始化的BinaryHeap
   let bh = BinaryHeap::from([1, 2]);
   println!("{:?}", bh);
   // 通过动态数组转换BinaryHeap
   let bh: BinaryHeap<i32>=vec![0,1,2].into_iter().collect();
   println!("{:?}", bh);
}