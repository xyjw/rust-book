use std::collections::BinaryHeap;

fn main() {
   // 创建一个空的BinaryHeap
   let mut bh = BinaryHeap::new();
   // 添加成员
   bh.push(1);
   bh.push(2);
   bh.push(4);
   println!("添加成员：{:?}", bh);
   // 遍历成员
   for x in &bh {
      println!("{}", x);
   }
   // 成员读取
   let res = bh.peek().unwrap();
   println!("成员读取：{:?}", res);
   // 成员读取并删除
   let res = bh.pop().unwrap();
   println!("成员读取并删除：{:?}", res);
   // 判断二叉堆是否为空
   let res = bh.is_empty();
   println!("判断二叉堆是否为空：{:?}", res);
   // 清空二叉堆
   bh.clear();
   println!("清空二叉堆：{:?}", bh);
}