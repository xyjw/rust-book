use std::collections::HashSet;

fn main() {
    // 创建带初始化的HashSet
    let mut hs: HashSet<i32> = HashSet::from([1, 2, 3]);
    println!("{:?}", hs);
    // 插入数据
    hs.insert(66);
    println!("{:?}", hs);
    // 遍历HashSet
    for &num in &hs {
        println!("{}", num);
    }
    // 判断成员是否存在
    let res = hs.contains(&66);
    println!("判断66是否存在：{:?}", res);
    // 删除成员
    hs.remove(&2);
    println!("{:?}", hs);
    // 清空集合
    hs.clear();
    println!("{:?}", hs);
}