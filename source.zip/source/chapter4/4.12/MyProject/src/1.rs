use std::collections::HashSet;

fn main() {
    // 创建一个空的HashSet
    let hs: HashSet<i32> = HashSet::new();
    println!("{:?}", hs);

    // 创建带初始化的HashSet
    let hs: HashSet<i32> = HashSet::from([2, 2, 3]);
    println!("{:?}", hs);

    // 通过动态数组转换HashSet
    let hs: HashSet<i32> = vec![1, 2, 2, 3].into_iter().collect();
    println!("{:?}", hs);
}