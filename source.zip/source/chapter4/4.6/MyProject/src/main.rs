fn main() {  
    let s = "hello world";
    // 判断字符串首位是否含有子字符串
    let index = s.starts_with("he");
    println!("字符串首位是否含有子字符串：{}", index);
    // 判断字符串末位是否含有子字符串
    let index = s.ends_with("dd");
    println!("字符串末位是否含有子字符串：{}", index);
    // 判断字符串是否含有子字符串
    let index = s.contains("wor");
    println!("字符串是否含有子字符串：{}", index);
    // 查找子字符串在字符串的索引
    let index = s.find("or");
    if let Some(pos) = index{
        println!("查找子字符串在字符串的索引：{}", pos);
    };
    // 输出字符出现的次数
    for str in s.matches("l"){
        println!("字符{}出现了",str);
    }
    println!("字符出现的次数：{}", s.matches("l").count());
    // 输出字符出现的次数和索引位置
    for (i, v) in s.match_indices("l"){
        println!("字符{}出现了，索引位置：{}", v, i);
    }
    println!("字符出现的次数：{}", s.match_indices("l").count());
}
