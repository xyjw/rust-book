use std::sync::Arc;
use tera::{Context, Tera};
use std::collections::HashMap;
use url::form_urlencoded::parse;
mod messagedb;
use sea_orm::*;
use messagedb::{prelude::*, *};
use tokio::{
    net::{TcpListener, TcpStream},
    io::{AsyncReadExt, AsyncWriteExt},
};
use chrono::Local;
use std::env;

// 创建数据库连接
async fn connect() -> Result<DatabaseConnection, DbErr>  {
    let opt = ConnectOptions::new(
		"mysql://root:1234@127.0.0.1:3306/messagedb");
    let db = Database::connect(opt).await?;
    Ok(db)
}

// 响应构造器
fn build_response(
    code: u16,
    status: &str,
    content_type: &str,
    body: Vec<u8>
) -> Vec<u8> {
    // 设置响应头
    let headers = format!(
        "HTTP/1.1 {} {}\r\n\
         Content-Type: {}\r\n\
         Content-Length: {}\r\n\r\n",
        code, status,
        content_type,
        body.len()
    );
    let mut response = headers.into_bytes();
    // 设置响应数据
    response.extend(body);
    response
}
// MIME类型
fn get_mime(path: &str) -> &str {
    match path.split('.').last() {
        Some("png") => "image/png",
        Some("jpg") | Some("jpeg") => "image/jpeg",
        Some("gif") => "image/gif",
        Some("css") => "text/css",
        Some("js") => "application/javascript",
        Some("html") => "text/html",
        _ => "application/octet-stream",
    }
}
// 静态文件服务
async fn serve_static(path: &str) -> Result<Vec<u8>, DbErr> {
    // 将路径地址改为文件地址
    let path_temp = format!("static{}", path.replace("/static", ""));
    let work_dir = env::current_dir().expect("无法获取工作目录");
    let file_path = work_dir.join(path_temp);
    // 读取文件
    let content = std::fs::read(&file_path).unwrap();
    // 构建响应内容
    let res = build_response(200, "OK", get_mime(&file_path.to_str().unwrap()), content);
    Ok(res)
}

// 发送HTML首页响应
async fn response_index_get(tera: &Tera, db: &DatabaseConnection) -> Result<Vec<u8>, DbErr> {
    let mut context = Context::new();
    // 读写数据库，将数据写入动态数组contents
    let mut contents = vec![];
    let data = message::Entity::find().all(db).await?;
    for d in data {
        let mut hp: HashMap<String, String> = HashMap::new();
        hp.insert("id".to_string(), d.id.to_string());
        hp.insert("name".to_string(), d.name.unwrap().to_string());
        hp.insert("content".to_string(), d.content.unwrap().to_string());
        hp.insert("created".to_string(), d.created.unwrap().to_string());
        contents.push(hp);
    }
    // 将动态数组传递给模版变量contents
    context.insert("contents", &contents);
    // 渲染模版文件
    let render = tera.render("index.html", &context);
    // 构建响应内容
    let res = build_response(200, "OK", "text/html", render.unwrap().into_bytes());
    Ok(res)
}

// 信息提交
async fn response_index_post(body: &str, db: &DatabaseConnection) -> Result<Vec<u8>, DbErr> {
    // 解析表单数据
    let form_data: HashMap<_, _> = parse(body.as_bytes())
        .into_owned()
        .map(|(k, v)| (k, v))
        .collect();
    // 写入数据
    let mut data = message::ActiveModel {
        name: ActiveValue::Set(
            Some(form_data["name"].to_string())),
        content: ActiveValue::Set(
            Some(form_data["content"].to_string())),
        created: ActiveValue::Set(
			Some(Local::now().date_naive())),
        updated: ActiveValue::Set(
			Some(Local::now().naive_local())),
        ..Default::default()
    };
    message::Entity::insert(data).exec(db).await?;
    // 重定向首页
    let headers = format!(
        "HTTP/1.1 302 Found\r\n\
         Location: /\r\n\
         Content-Length: 0\r\n\r\n",
    );
    Ok(headers.into_bytes())
}

// 发送404未找到响应
async fn response_404(tera: &Tera) -> Result<Vec<u8>, DbErr> {
    let mut context = Context::new();
    // 渲染模版文件
    let render = tera.render("404.html", &context);
    // 构建响应内容
    let res = build_response(200, "OK", "text/html", render.unwrap().into_bytes());
    Ok(res)
}

// 路由处理
async fn handle_connection(mut stream: TcpStream, tera: &Tera, db: &DatabaseConnection) -> Result<(), Box<dyn std::error::Error>>{
    let mut buffer = [0; 1024];
    stream.read(&mut buffer).await?;
    // 转换数据格式
    let request = String::from_utf8_lossy(&buffer[..]);
    // 获取请求参数
    let body = request.split("\r\n\r\n").nth(1).unwrap_or_default();
    // 获取请求参数和请求路径
    let request_line = request.lines().next().unwrap_or("");
    let method = request_line.split_whitespace().nth(0).unwrap_or("");
    let path = request_line.split_whitespace().nth(1).unwrap_or("");
    // 路由分发
    let response = match (method, path) {
        ("GET", "/") => response_index_get(tera, &db).await?,
        ("POST", "/") => response_index_post(body, &db).await?,
        (_, path) if path.starts_with("/static/") => serve_static(&path).await?,
        _ => response_404(tera).await?,
    };
    // 发送响应
    stream.write_all(&response).await?;
    stream.flush().await?;
    Ok(())
}

// 主函数
#[tokio::main]
async fn main() -> Result<(),Box<dyn std::error::Error>>{
    // 创建数据库连接
    let db = Arc::new(connect().await?);
    // 初始化模板引擎
    let work_dir = env::current_dir().expect("无法获取工作目录");
    let fp = work_dir.join("templates/**/*.html");
    let tera = Arc::new(
        Tera::new(fp.to_str().unwrap())
            .expect("Failed to initialize template engine")
    );
    println!("{:?}", tera);
    // 绑定到本地8080端口，创建TCP监听器
    let listener = TcpListener::bind("127.0.0.1:8080").await?;
    println!("Server listening on http://127.0.0.1:8080");
    loop {
        // 持续处理传入的连接请求
        let (stream, _) = listener.accept().await?;
        let tera_clone = Arc::clone(&tera);
        let db_clone = Arc::clone(&db);
        // 异步执行函数handle_connection
        tokio::spawn(async move {
            if let Err(e) = handle_connection(stream, &tera_clone, &db_clone).await {
                println!("Connection error: {}", e);
            }
        });
    };
}