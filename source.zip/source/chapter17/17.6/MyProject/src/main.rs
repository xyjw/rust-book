#[cfg(target_os = "windows")]
fn function() {
    println!("这是在Windows运行");
}

#[cfg(target_os = "linux")]
fn function() {
    println!("这是在Linux运行");
}

#[cfg(target_os = "macos")]
fn function() {
    println!("这是在MacOS运行");
}

fn main() {
   function();
}
