use std::thread;

fn main() {
    // 创建动态数组
    let v = vec![1, 2, 3];
    // 创建多线程任务，输出动态数组
    let handle = thread::spawn(move || {
        println!("动态数组：{:?}", v);
    });
    // 等待多线程任务执行完成
    handle.join().unwrap();
    println!("主线程执行完成");
}