use std::thread;

fn tasks(){
    for i in 1..5 {
        println!("多线程任务：{}", i);
    }
}

fn main() {
    // 创建多线程任务
    let handle = thread::spawn(tasks);
    // 等待多线程任务执行完成
    handle.join().unwrap();
    println!("主线程执行完成");
}