use std::sync::atomic::{AtomicI32, Ordering};
fn main() {
    // 创建Atomic类型对象，初始值为0
    let a = AtomicI32::new(0);
    // 对Atomic类型对象写入数据
    // 将初始值0改为1
    a.store(1, Ordering::Relaxed);
    // 对Atomic类型对象自增加2
    a.fetch_add(2, Ordering::Relaxed);
    // 读取Atomic类型对象
    let value = a.load(Ordering::Relaxed);
    println!("读取Atomic类型对象：{}", value);
    // 对Atomic类型对象自减1
    a.fetch_sub(1, Ordering::Relaxed);
    let value = a.load(Ordering::Relaxed);
    println!("读取Atomic类型对象：{}", value);
}