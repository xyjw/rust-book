use std::sync::Arc;
use std::sync::atomic::{AtomicI32, Ordering};
use std::thread;
fn main() {
    // 创建Arc<AtomicI32>对象，Atomic的数值为0
    let counter = Arc::new(AtomicI32::new(0));
    // 创建动态数组，用于存放多线程对象
    let mut handles = vec![];
    // 循环创建多个多线程对象
    for i in 0..5 {
        // 克隆counter
        let counter = Arc::clone(&counter);
        // 多线程
        let handle = thread::spawn(move || {
            // 对Atomic类型对象自增加1，内存顺序为SeqCst
            counter.fetch_add(1, Ordering::SeqCst);
            // 读取并输出Atomic类型对象，内存顺序为SeqCst
            let value = counter.load(Ordering::SeqCst);
            println!("第{}次读取Atomic：{}", i, value);
        });
        // 多线程对象写入数组
        handles.push(handle);
    }
    // 等待多线程执行完成
    for handle in handles {
        handle.join().unwrap();
    }
}
