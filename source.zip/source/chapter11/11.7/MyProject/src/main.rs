use tokio::{
    sync::mpsc,
    time::{sleep, Duration},
};

// 生产者协程
async fn producer(int_tx: mpsc::Sender<i32>, exit_tx: mpsc::Sender<bool>) {
    // 生成3个菜品
    for i in 0..3 {
        println!("厨师完成菜式{}的制作", i);
        int_tx.send(i).await.expect("发送失败");
        sleep(Duration::from_secs(2)).await;
    }

    // 发送结束信号
    exit_tx.send(true).await.expect("发送失败");
    println!("厨师完成所有菜式");
}
// 消费者协程
async fn consumer(mut int_rx: mpsc::Receiver<i32>, mut exit_rx: mpsc::Receiver<bool>) {
    loop {
        tokio::select! {
            // 处理退出信号
            Some(_) = exit_rx.recv() => {
                println!("厨师下班，店铺不经营！");
                break;
            }
            // 处理菜品数据
            Some(v) = int_rx.recv() => {
                println!("顾客吃了菜式{}！", v);
            }
            // 默认等待
            _ = sleep(Duration::from_secs(3)) => {
                println!("顾客等待中...");
            }
        }
    }
}
#[tokio::main]
async fn main() {
    // 创建带缓冲的通道 (容量3)
    let (int_tx, int_rx) = mpsc::channel(3);
    let (exit_tx, exit_rx) = mpsc::channel(1);
    // 启动生产者和消费者
    let producer = producer(int_tx, exit_tx);
    let consumer = consumer(int_rx, exit_rx);
    println!("main进入阻塞状态...等待并发程序结束");
    // 等待任务完成
    tokio::join!(producer, consumer);
}