use std::sync::mpsc;
use std::thread;

fn main() {
    // 创建异步通道，生成发送者tx和接收者rx
    let (tx, rx) = mpsc::channel();
    // 克隆发送者
    let tx1 = tx.clone();
    // 线程1发送信息
    thread::spawn(move || {
        tx.send(String::from("线程1发送信息")).unwrap();
    });
    // 线程2发送信息
    thread::spawn(move || {
        tx1.send(String::from("线程2发送信息")).unwrap();
    });
    // 线程3接收信息
    thread::spawn(move || {
        for received in rx {
            println!("线程3接收：{}", received);
        }
    });    
}