use std::sync::{Arc, Mutex};
use std::thread;

fn main() {
    // 创建Arc<Mutex<T>>对象，共享资源的数值为0
    let counter = Arc::new(Mutex::new(0));
    // 创建动态数组，用于存放多线程对象
    let mut handles = vec![];
    // 循环创建多个多线程对象
    for i in 0..5 {
        // 克隆counter
        let counter = Arc::clone(&counter);
        // 多线程
        let handle = thread::spawn(move || {
            // 对Arc<Mutex<T>>加锁处理
            let mut num = counter.lock().unwrap();
            // 获取共享资源的读写权限，对变量num解引用即可
            println!("循环次数：{}次，第{}次获取锁", i, *num);
            // 锁的获取次数累加1
            *num += 1;
        });
        // 多线程对象写入数组
        handles.push(handle);
    }
    // 等待多线程执行完成
    for handle in handles {
        handle.join().unwrap();
    }
    println!("锁的获取总数：{}", *counter.lock().unwrap());
}