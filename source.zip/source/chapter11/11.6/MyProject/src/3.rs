use futures::executor::block_on;
// 定义异步任务
async fn hello_world() {
    println!("hello, world!");
}
async fn hello_rust() {
    println!("hello, rust!");
}
fn main() {
    // 返回一个Future
    let future1 = hello_world();
    let future2 = hello_rust();
    // 执行`Future`并等待运行完成
    block_on(future1);
    block_on(future2);
}