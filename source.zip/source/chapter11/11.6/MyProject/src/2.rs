use futures::executor::block_on;
// 定义异步任务
async fn hello_rust() {
    println!("hello, rust!");
}
async fn hello_world() {
    // 等待hello_rust运行完成才往下执行
    hello_rust().await;
    println!("hello, world!");
}
fn main() {
    let future = hello_world();
    block_on(future);
}