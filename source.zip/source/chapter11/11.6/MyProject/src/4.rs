use futures::join;
use futures::executor::block_on;
// 定义异步任务，设置返回值
async fn hello_world() -> i32 {
    println!("hello, world!");
    return 1;
}
async fn hello_rust() -> i32{
    println!("hello, rust!");
    return 2;
}
// 定义异步任务
// 分别执行异步任务hello_world和hello_rust
async fn run_hello(){
    let future1 = hello_world();
    let future2 = hello_rust();
    // 获取异步任务的返回值
    let (r1, r2) = join!(future1, future2);
    println!("hello_world的返回值：{:?}", r1);
    println!("hello_rust的返回值：{:?}", r2);
}
fn main() {
    // 执行异步任务run_hello
    let future3 = run_hello();
    block_on(future3);
}