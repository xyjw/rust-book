// `block_on`阻塞程序直到指定的`Future`执行完成
// 通过阻塞方式以等待任务完成是最简单粗暴
use futures::executor::block_on;
// 定义异步任务
async fn hello_world() {
    println!("hello, world!");
}
fn main() {
    // 返回一个Future
    let future = hello_world();
    // 执行`Future`并等待运行完成
    block_on(future);
}
