use futures::{
    future::FutureExt,
    pin_mut,
    select,
};
use futures::executor::block_on;
// 定义异步任务，设置返回值
async fn hello_world() -> i32 {
    println!("hello, world!");
    return 1;
}
async fn hello_rust() -> i32{
    println!("hello, rust!");
    return 2;
}
// 定义异步任务
// 分别执行异步任务hello_world和hello_rust
async fn run_hello(){
    // 当Future对象执行完成后，在后续循环不会再次执行。
    let future1 = hello_world().fuse();
    let future2 = hello_rust().fuse();
    // 用于在不改变对象的内存地址的情况下进行对象的轮询。
    pin_mut!(future1, future2);
    // 死循环
    // 导致同一个Future对象多次执行
    // 因此Future对象需要调用fuse()
    loop {
        select! {
            r1 = future1 => {
                println!("hello_world返回值：{:?}", r1);
            },
            r2 = future2 => {
                println!("hello_rust返回值：{:?}", r2);
            },
            default => {
                println!("等一等")
            },
            complete => {
                // 终止循环
                break;
            },
        }
    }
}
fn main() {
    // 执行异步任务run_hello
    let future3 = run_hello();
    block_on(future3);
}