use rand::Rng;
use std::io;
use std::cmp::Ordering;

fn main() {
    // 从1到100随机选择一个数字
    let secret_number = rand::thread_rng().gen_range(1..=100);
    println!("欢迎来到猜数字游戏！从1到100之间选一个数字。");
    for number in 1..=6 {
        // 定义变量guess
        let mut guess = String::new();
        // 判断循环次数，等于6代表没有游戏机会
        if number == 6{
            println!("你的机会用完了，你输了");
            break;
        }
        println!("请输入你的猜测：");
        // 读取玩家输入的数据
        io::stdin().read_line(&mut guess).expect("读取输入失败");
        // 玩家输入数据转换为整型
        let guess: u32 = match guess.trim().parse() {
            Ok(num) => num,
            Err(err) => {
                println!("请输入一个有效的数字: {err}");
                continue;  
            }  
        };  
        // 表达式match用于进行模式匹配
        // guess.cmp(&secret_number)是比较变量guess和secret_number
        // 枚举Ordering表示排序关系：小于(Less)、等于(Equal)、大于(Greater)
        match guess.cmp(&secret_number) {
            Ordering::Less => println!("太小了！"),
            Ordering::Greater => println!("太大了！"),
            Ordering::Equal => {
                println!("恭喜你，猜对了！数字是：{}", secret_number);
                break;
            }
        }
    }
}